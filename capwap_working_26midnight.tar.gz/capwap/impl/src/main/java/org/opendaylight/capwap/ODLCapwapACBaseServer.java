package org.opendaylight.capwap;

public interface ODLCapwapACBaseServer extends AutoCloseable{
    void start() throws Exception;    
}
