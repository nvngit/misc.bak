package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217;
import org.opendaylight.yangtools.yang.binding.DataRoot;


/**
 * Service definition for capwap plugin
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap-impl&lt;/b&gt;
 * &lt;br&gt;Source path: &lt;i&gt;META-INF/yang/capwap-impl.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * module capwap-impl {
 *     yang-version 1;
 *     namespace "urn:opendaylight:capwap:impl";
 *     prefix "capwap-impl";
 *
 *     import opendaylight-md-sal-binding { prefix "mdsal"; }
 *     
 *     import capwap { prefix "capwap"; }
 *     
 *     import config { prefix "config"; }
 *     revision 2015-02-17 {
 *         description "Service definition for capwap plugin
 *         ";
 *     }
 *
 *     container capwap-ac-root {
 *         leaf ac-name {
 *             type string;
 *         }
 *         list discovered-wtps {
 *             key "ipv4-addr"
 *             leaf ipv4-addr {
 *                 type string;
 *             }
 *             container board-data {
 *                 leaf vendorid {
 *                     type vendor-id;
 *                 }
 *                 leaf type {
 *                     type uint16;
 *                 }
 *                 leaf length {
 *                     type uint16;
 *                 }
 *                 leaf value {
 *                     type binary;
 *                 }
 *                 uses wtp-board-data;
 *             }
 *             container descriptor {
 *                 leaf max-radios {
 *                     type uint8;
 *                 }
 *                 leaf radios-in-use {
 *                     type uint8;
 *                 }
 *                 leaf num-encrypt {
 *                     type uint8;
 *                 }
 *                 leaf vendorid {
 *                     type vendor-id;
 *                 }
 *                 leaf type {
 *                     type uint16;
 *                 }
 *                 leaf length {
 *                     type uint16;
 *                 }
 *                 leaf value {
 *                     type binary;
 *                 }
 *                 leaf resvd {
 *                     type uint8;
 *                 }
 *                 leaf wbid {
 *                     type uint8;
 *                 }
 *                 leaf capabilities {
 *                     type uint16;
 *                 }
 *                 uses wtp-descriptor;
 *             }
 *             container frame-tunnel-mode {
 *                 leaf rsvd {
 *                     type uint8;
 *                 }
 *                 leaf bit-n {
 *                     type boolean;
 *                 }
 *                 leaf bit-e {
 *                     type boolean;
 *                 }
 *                 leaf bit-l {
 *                     type boolean;
 *                 }
 *                 leaf bit-r {
 *                     type boolean;
 *                 }
 *                 uses wtp-frame-tunnel-mode;
 *             }
 *             container mac-type {
 *                 leaf mac-type {
 *                     type uint8;
 *                 }
 *                 uses wtp-mac-type;
 *             }
 *             container radio-info {
 *                 leaf radio-id {
 *                     type uint8;
 *                 }
 *                 leaf rsvd {
 *                     type uint8;
 *                 }
 *                 leaf rsvd1 {
 *                     type uint16;
 *                 }
 *                 leaf rsvd2 {
 *                     type uint8;
 *                 }
 *                 leaf rsvd3 {
 *                     type uint8;
 *                 }
 *                 leaf type-n {
 *                     type boolean;
 *                 }
 *                 leaf type-g {
 *                     type boolean;
 *                 }
 *                 leaf type-a {
 *                     type boolean;
 *                 }
 *                 leaf type-b {
 *                     type boolean;
 *                 }
 *                 uses wtp-radio-info;
 *             }
 *             container discovery-type {
 *                 leaf discovery-type {
 *                     type uint8;
 *                 }
 *                 uses wtp-discovery-type;
 *             }
 *             uses discovered-wtp;
 *         }
 *         uses capwap-ac;
 *     }
 *
 *     augment \(urn:opendaylight:params:xml:ns:yang:controller:config)modules\(urn:opendaylight:params:xml:ns:yang:controller:config)module\(urn:opendaylight:params:xml:ns:yang:controller:config)configuration {
 *         status CURRENT;
 *         case capwap-impl {
 *             leaf max-discovered-wtps {
 *                 type int32;
 *             }
 *             container broker {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *                 leaf name {
 *                     type leafref;
 *                 }
 *                 uses service-ref {
 *                     refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                         leaf type {
 *                             type leafref;
 *                         }
 *                     }
 *                 }
 *             }
 *             container rpc-registry {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *                 leaf name {
 *                     type leafref;
 *                 }
 *                 uses service-ref {
 *                     refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                         leaf type {
 *                             type leafref;
 *                         }
 *                     }
 *                 }
 *             }
 *             container notification-service {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *                 leaf name {
 *                     type leafref;
 *                 }
 *                 uses service-ref {
 *                     refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                         leaf type {
 *                             type leafref;
 *                         }
 *                     }
 *                 }
 *             }
 *             container data-broker {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *                 leaf name {
 *                     type leafref;
 *                 }
 *                 uses service-ref {
 *                     refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                         leaf type {
 *                             type leafref;
 *                         }
 *                     }
 *                 }
 *             }
 *         }
 *     }
 *
 *     identity capwap-impl {
 *         base "()IdentitySchemaNodeImpl[base=null, qname=(urn:opendaylight:params:xml:ns:yang:controller:config?revision=2013-04-05)module-type]";
 *         status CURRENT;
 *     }
 * }
 * &lt;/pre&gt;
 *
 */
public interface CapwapImplData
    extends
    DataRoot
{




    /**
     * the USC related whole topology.
     *
     */
    CapwapAcRoot getCapwapAcRoot();

}

