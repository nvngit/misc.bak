package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217.modules.module.configuration;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217.modules.module.configuration.capwap.impl.Broker;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217.modules.module.configuration.capwap.impl.RpcRegistry;
import org.opendaylight.yangtools.yang.binding.DataObject;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217.modules.module.configuration.capwap.impl.DataBroker;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217.modules.module.configuration.capwap.impl.NotificationService;
import org.opendaylight.yang.gen.v1.urn.opendaylight.params.xml.ns.yang.controller.config.rev130405.modules.module.Configuration;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap-impl&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap-impl.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * case capwap-impl {
 *     leaf max-discovered-wtps {
 *         type int32;
 *     }
 *     container broker {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 *     container rpc-registry {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 *     container notification-service {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 *     container data-broker {
 *         leaf type {
 *             type leafref;
 *         }
 *         leaf name {
 *             type leafref;
 *         }
 *         uses service-ref {
 *             refine (urn:opendaylight:capwap:impl?revision=2015-02-17)type {
 *                 leaf type {
 *                     type leafref;
 *                 }
 *             }
 *         }
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap-impl/modules/module/configuration/(urn:opendaylight:capwap:impl?revision=2015-02-17)capwap-impl&lt;/i&gt;
 *
 */
public interface CapwapImpl
    extends
    DataObject,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.impl.rev150217.modules.module.configuration.CapwapImpl>,
    Configuration
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:impl","2015-02-17","capwap-impl"));

    /**
     * maximum number of WTPs which can be discovered and information maintained
     *
     */
    java.lang.Integer getMaxDiscoveredWtps();
    
    Broker getBroker();
    
    RpcRegistry getRpcRegistry();
    
    NotificationService getNotificationService();
    
    DataBroker getDataBroker();

}

