package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import com.google.common.collect.Range;
import java.util.Collections;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.VendorId;
import java.util.Map;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import com.google.common.collect.ImmutableList;
import java.math.BigInteger;
import java.util.List;
import java.util.Arrays;
import org.opendaylight.yangtools.yang.binding.Augmentation;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor
 *
 */
public class DescriptorBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor> {

    private java.lang.Integer _capabilities;
    private static List<Range<BigInteger>> _capabilities_range;
    private java.lang.Integer _length;
    private static List<Range<BigInteger>> _length_range;
    private java.lang.Short _maxRadios;
    private static List<Range<BigInteger>> _maxRadios_range;
    private java.lang.Short _numEncrypt;
    private static List<Range<BigInteger>> _numEncrypt_range;
    private java.lang.Short _radiosInUse;
    private static List<Range<BigInteger>> _radiosInUse_range;
    private java.lang.Short _resvd;
    private static List<Range<BigInteger>> _resvd_range;
    private java.lang.Integer _type;
    private static List<Range<BigInteger>> _type_range;
    private byte[] _value;
    private VendorId _vendorid;
    private static List<Range<BigInteger>> _vendorid_range;
    private java.lang.Short _wbid;
    private static List<Range<BigInteger>> _wbid_range;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> augmentation = new HashMap<>();

    public DescriptorBuilder() {
    }
    public DescriptorBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor arg) {
        this._maxRadios = arg.getMaxRadios();
        this._radiosInUse = arg.getRadiosInUse();
        this._numEncrypt = arg.getNumEncrypt();
        this._vendorid = arg.getVendorid();
        this._type = arg.getType();
        this._length = arg.getLength();
        this._value = arg.getValue();
        this._resvd = arg.getResvd();
        this._wbid = arg.getWbid();
        this._capabilities = arg.getCapabilities();
    }
    public DescriptorBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe arg) {
        this._vendorid = arg.getVendorid();
        this._type = arg.getType();
        this._length = arg.getLength();
        this._value = arg.getValue();
    }
    public DescriptorBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe arg) {
        this._resvd = arg.getResvd();
        this._wbid = arg.getWbid();
        this._capabilities = arg.getCapabilities();
    }

    public DescriptorBuilder(Descriptor base) {
        this._capabilities = base.getCapabilities();
        this._length = base.getLength();
        this._maxRadios = base.getMaxRadios();
        this._numEncrypt = base.getNumEncrypt();
        this._radiosInUse = base.getRadiosInUse();
        this._resvd = base.getResvd();
        this._type = base.getType();
        this._value = base.getValue();
        this._vendorid = base.getVendorid();
        this._wbid = base.getWbid();
        if (base instanceof DescriptorImpl) {
            DescriptorImpl _impl = (DescriptorImpl) base;
            this.augmentation = new HashMap<>(_impl.augmentation);
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe</li>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor</li>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe) {
            this._vendorid = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe)arg).getVendorid();
            this._type = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe)arg).getType();
            this._length = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe)arg).getLength();
            this._value = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe)arg).getValue();
            isValidArg = true;
        }
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor) {
            this._maxRadios = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor)arg).getMaxRadios();
            this._radiosInUse = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor)arg).getRadiosInUse();
            this._numEncrypt = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor)arg).getNumEncrypt();
            isValidArg = true;
        }
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe) {
            this._resvd = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe)arg).getResvd();
            this._wbid = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe)arg).getWbid();
            this._capabilities = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe)arg).getCapabilities();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptorSe, org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor, org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpEncryptionSe] \n" +
              "but was: " + arg
            );
        }
    }

    public java.lang.Integer getCapabilities() {
        return _capabilities;
    }
    
    public java.lang.Integer getLength() {
        return _length;
    }
    
    public java.lang.Short getMaxRadios() {
        return _maxRadios;
    }
    
    public java.lang.Short getNumEncrypt() {
        return _numEncrypt;
    }
    
    public java.lang.Short getRadiosInUse() {
        return _radiosInUse;
    }
    
    public java.lang.Short getResvd() {
        return _resvd;
    }
    
    public java.lang.Integer getType() {
        return _type;
    }
    
    public byte[] getValue() {
        return _value == null ? null : _value.clone();
    }
    
    public VendorId getVendorid() {
        return _vendorid;
    }
    
    public java.lang.Short getWbid() {
        return _wbid;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public DescriptorBuilder setCapabilities(java.lang.Integer value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _capabilities_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _capabilities_range));
            }
        }
        this._capabilities = value;
        return this;
    }
    public static List<Range<BigInteger>> _capabilities_range() {
        if (_capabilities_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_capabilities_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(65535L)));
                    _capabilities_range = builder.build();
                }
            }
        }
        return _capabilities_range;
    }
    
    public DescriptorBuilder setLength(java.lang.Integer value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _length_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _length_range));
            }
        }
        this._length = value;
        return this;
    }
    public static List<Range<BigInteger>> _length_range() {
        if (_length_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_length_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ONE, BigInteger.valueOf(1024L)));
                    _length_range = builder.build();
                }
            }
        }
        return _length_range;
    }
    
    public DescriptorBuilder setMaxRadios(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _maxRadios_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _maxRadios_range));
            }
        }
        this._maxRadios = value;
        return this;
    }
    public static List<Range<BigInteger>> _maxRadios_range() {
        if (_maxRadios_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_maxRadios_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(255L)));
                    _maxRadios_range = builder.build();
                }
            }
        }
        return _maxRadios_range;
    }
    
    public DescriptorBuilder setNumEncrypt(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _numEncrypt_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _numEncrypt_range));
            }
        }
        this._numEncrypt = value;
        return this;
    }
    public static List<Range<BigInteger>> _numEncrypt_range() {
        if (_numEncrypt_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_numEncrypt_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(255L)));
                    _numEncrypt_range = builder.build();
                }
            }
        }
        return _numEncrypt_range;
    }
    
    public DescriptorBuilder setRadiosInUse(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _radiosInUse_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _radiosInUse_range));
            }
        }
        this._radiosInUse = value;
        return this;
    }
    public static List<Range<BigInteger>> _radiosInUse_range() {
        if (_radiosInUse_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_radiosInUse_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(255L)));
                    _radiosInUse_range = builder.build();
                }
            }
        }
        return _radiosInUse_range;
    }
    
    public DescriptorBuilder setResvd(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _resvd_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _resvd_range));
            }
        }
        this._resvd = value;
        return this;
    }
    public static List<Range<BigInteger>> _resvd_range() {
        if (_resvd_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_resvd_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(7L)));
                    _resvd_range = builder.build();
                }
            }
        }
        return _resvd_range;
    }
    
    public DescriptorBuilder setType(java.lang.Integer value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _type_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _type_range));
            }
        }
        this._type = value;
        return this;
    }
    public static List<Range<BigInteger>> _type_range() {
        if (_type_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_type_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(4L)));
                    _type_range = builder.build();
                }
            }
        }
        return _type_range;
    }
    
    public DescriptorBuilder setValue(byte[] value) {
        this._value = value;
        return this;
    }
    
    public DescriptorBuilder setVendorid(VendorId value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value.getValue());
            boolean isValidRange = false;
            for (Range<BigInteger> r : _vendorid_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _vendorid_range));
            }
        }
        this._vendorid = value;
        return this;
    }
    public static List<Range<BigInteger>> _vendorid_range() {
        if (_vendorid_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_vendorid_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(4294967295L)));
                    _vendorid_range = builder.build();
                }
            }
        }
        return _vendorid_range;
    }
    
    public DescriptorBuilder setWbid(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _wbid_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _wbid_range));
            }
        }
        this._wbid = value;
        return this;
    }
    public static List<Range<BigInteger>> _wbid_range() {
        if (_wbid_range == null) {
            synchronized (DescriptorBuilder.class) {
                if (_wbid_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(31L)));
                    _wbid_range = builder.build();
                }
            }
        }
        return _wbid_range;
    }
    
    public DescriptorBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public DescriptorBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> augmentationType) {
        this.augmentation.remove(augmentationType);
        return this;
    }

    public Descriptor build() {
        return new DescriptorImpl(this);
    }

    private static final class DescriptorImpl implements Descriptor {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor.class;
        }

        private final java.lang.Integer _capabilities;
        private final java.lang.Integer _length;
        private final java.lang.Short _maxRadios;
        private final java.lang.Short _numEncrypt;
        private final java.lang.Short _radiosInUse;
        private final java.lang.Short _resvd;
        private final java.lang.Integer _type;
        private final byte[] _value;
        private final VendorId _vendorid;
        private final java.lang.Short _wbid;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> augmentation = new HashMap<>();

        private DescriptorImpl(DescriptorBuilder base) {
            this._capabilities = base.getCapabilities();
            this._length = base.getLength();
            this._maxRadios = base.getMaxRadios();
            this._numEncrypt = base.getNumEncrypt();
            this._radiosInUse = base.getRadiosInUse();
            this._resvd = base.getResvd();
            this._type = base.getType();
            this._value = base.getValue();
            this._vendorid = base.getVendorid();
            this._wbid = base.getWbid();
                switch (base.augmentation.size()) {
                case 0:
                    this.augmentation = Collections.emptyMap();
                    break;
                    case 1:
                        final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> e = base.augmentation.entrySet().iterator().next();
                        this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>>singletonMap(e.getKey(), e.getValue());
                    break;
                default :
                    this.augmentation = new HashMap<>(base.augmentation);
                }
        }

        @Override
        public java.lang.Integer getCapabilities() {
            return _capabilities;
        }
        
        @Override
        public java.lang.Integer getLength() {
            return _length;
        }
        
        @Override
        public java.lang.Short getMaxRadios() {
            return _maxRadios;
        }
        
        @Override
        public java.lang.Short getNumEncrypt() {
            return _numEncrypt;
        }
        
        @Override
        public java.lang.Short getRadiosInUse() {
            return _radiosInUse;
        }
        
        @Override
        public java.lang.Short getResvd() {
            return _resvd;
        }
        
        @Override
        public java.lang.Integer getType() {
            return _type;
        }
        
        @Override
        public byte[] getValue() {
            return _value == null ? null : _value.clone();
        }
        
        @Override
        public VendorId getVendorid() {
            return _vendorid;
        }
        
        @Override
        public java.lang.Short getWbid() {
            return _wbid;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_capabilities == null) ? 0 : _capabilities.hashCode());
            result = prime * result + ((_length == null) ? 0 : _length.hashCode());
            result = prime * result + ((_maxRadios == null) ? 0 : _maxRadios.hashCode());
            result = prime * result + ((_numEncrypt == null) ? 0 : _numEncrypt.hashCode());
            result = prime * result + ((_radiosInUse == null) ? 0 : _radiosInUse.hashCode());
            result = prime * result + ((_resvd == null) ? 0 : _resvd.hashCode());
            result = prime * result + ((_type == null) ? 0 : _type.hashCode());
            result = prime * result + ((_value == null) ? 0 : Arrays.hashCode(_value));
            result = prime * result + ((_vendorid == null) ? 0 : _vendorid.hashCode());
            result = prime * result + ((_wbid == null) ? 0 : _wbid.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor other = (org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor)obj;
            if (_capabilities == null) {
                if (other.getCapabilities() != null) {
                    return false;
                }
            } else if(!_capabilities.equals(other.getCapabilities())) {
                return false;
            }
            if (_length == null) {
                if (other.getLength() != null) {
                    return false;
                }
            } else if(!_length.equals(other.getLength())) {
                return false;
            }
            if (_maxRadios == null) {
                if (other.getMaxRadios() != null) {
                    return false;
                }
            } else if(!_maxRadios.equals(other.getMaxRadios())) {
                return false;
            }
            if (_numEncrypt == null) {
                if (other.getNumEncrypt() != null) {
                    return false;
                }
            } else if(!_numEncrypt.equals(other.getNumEncrypt())) {
                return false;
            }
            if (_radiosInUse == null) {
                if (other.getRadiosInUse() != null) {
                    return false;
                }
            } else if(!_radiosInUse.equals(other.getRadiosInUse())) {
                return false;
            }
            if (_resvd == null) {
                if (other.getResvd() != null) {
                    return false;
                }
            } else if(!_resvd.equals(other.getResvd())) {
                return false;
            }
            if (_type == null) {
                if (other.getType() != null) {
                    return false;
                }
            } else if(!_type.equals(other.getType())) {
                return false;
            }
            if (_value == null) {
                if (other.getValue() != null) {
                    return false;
                }
            } else if(!Arrays.equals(_value, other.getValue())) {
                return false;
            }
            if (_vendorid == null) {
                if (other.getVendorid() != null) {
                    return false;
                }
            } else if(!_vendorid.equals(other.getVendorid())) {
                return false;
            }
            if (_wbid == null) {
                if (other.getWbid() != null) {
                    return false;
                }
            } else if(!_wbid.equals(other.getWbid())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                DescriptorImpl otherImpl = (DescriptorImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("Descriptor [");
            boolean first = true;
        
            if (_capabilities != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_capabilities=");
                builder.append(_capabilities);
             }
            if (_length != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_length=");
                builder.append(_length);
             }
            if (_maxRadios != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_maxRadios=");
                builder.append(_maxRadios);
             }
            if (_numEncrypt != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_numEncrypt=");
                builder.append(_numEncrypt);
             }
            if (_radiosInUse != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_radiosInUse=");
                builder.append(_radiosInUse);
             }
            if (_resvd != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_resvd=");
                builder.append(_resvd);
             }
            if (_type != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_type=");
                builder.append(_type);
             }
            if (_value != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_value=");
                builder.append(Arrays.toString(_value));
             }
            if (_vendorid != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_vendorid=");
                builder.append(_vendorid);
             }
            if (_wbid != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_wbid=");
                builder.append(_wbid);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
