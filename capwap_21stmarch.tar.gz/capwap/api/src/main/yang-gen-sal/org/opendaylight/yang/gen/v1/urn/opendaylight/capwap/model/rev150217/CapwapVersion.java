package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;


/**
 * The enumeration built-in type represents values from a set of assigned names.
 *
 */
public enum CapwapVersion {
    Default(0)
    ;


    int value;
    private static final java.util.Map<java.lang.Integer, CapwapVersion> VALUE_MAP;

    static {
        final com.google.common.collect.ImmutableMap.Builder<java.lang.Integer, CapwapVersion> b = com.google.common.collect.ImmutableMap.builder();
        for (CapwapVersion enumItem : CapwapVersion.values())
        {
            b.put(enumItem.value, enumItem);
        }

        VALUE_MAP = b.build();
    }

    private CapwapVersion(int value) {
        this.value = value;
    }

    /**
     * @return integer value
     */
    public int getIntValue() {
        return value;
    }

    /**
     * @param valueArg
     * @return corresponding CapwapVersion item
     */
    public static CapwapVersion forValue(int valueArg) {
        return VALUE_MAP.get(valueArg);
    }
}
