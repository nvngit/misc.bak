package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * Capwap Control Header
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping capwap-control-header {
 *     leaf message-type {
 *         type uint32;
 *     }
 *     leaf seq-number {
 *         type uint8;
 *     }
 *     leaf msg-elem-length {
 *         type uint16;
 *     }
 *     leaf flags {
 *         type uint8;
 *     }
 *     leaf message-elements {
 *         type binary;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/capwap-control-header&lt;/i&gt;
 *
 */
public interface CapwapControlHeader
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","capwap-control-header"));

    java.lang.Long getMessageType();
    
    java.lang.Short getSeqNumber();
    
    java.lang.Integer getMsgElemLength();
    
    java.lang.Short getFlags();
    
    byte[] getMessageElements();

}

