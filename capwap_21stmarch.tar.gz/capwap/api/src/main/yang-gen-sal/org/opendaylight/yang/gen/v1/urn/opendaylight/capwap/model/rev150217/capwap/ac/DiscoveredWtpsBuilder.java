package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo;
import java.util.Collections;
import java.util.Map;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.MacType;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.DiscoveryType;
import org.opendaylight.yangtools.yang.binding.Augmentation;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps
 *
 */
public class DiscoveredWtpsBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps> {

    private BoardData _boardData;
    private Descriptor _descriptor;
    private DiscoveryType _discoveryType;
    private FrameTunnelMode _frameTunnelMode;
    private java.lang.String _ipv4Addr;
    private DiscoveredWtpsKey _key;
    private MacType _macType;
    private RadioInfo _radioInfo;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> augmentation = new HashMap<>();

    public DiscoveredWtpsBuilder() {
    }
    public DiscoveredWtpsBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp arg) {
        this._boardData = arg.getBoardData();
        this._descriptor = arg.getDescriptor();
        this._frameTunnelMode = arg.getFrameTunnelMode();
        this._macType = arg.getMacType();
        this._radioInfo = arg.getRadioInfo();
        this._discoveryType = arg.getDiscoveryType();
    }

    public DiscoveredWtpsBuilder(DiscoveredWtps base) {
        if (base.getKey() == null) {
            this._key = new DiscoveredWtpsKey(
                base.getIpv4Addr()
            );
            this._ipv4Addr = base.getIpv4Addr();
        } else {
            this._key = base.getKey();
            this._ipv4Addr = _key.getIpv4Addr();
        }
        this._boardData = base.getBoardData();
        this._descriptor = base.getDescriptor();
        this._discoveryType = base.getDiscoveryType();
        this._frameTunnelMode = base.getFrameTunnelMode();
        this._macType = base.getMacType();
        this._radioInfo = base.getRadioInfo();
        if (base instanceof DiscoveredWtpsImpl) {
            DiscoveredWtpsImpl _impl = (DiscoveredWtpsImpl) base;
            this.augmentation = new HashMap<>(_impl.augmentation);
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp) {
            this._boardData = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp)arg).getBoardData();
            this._descriptor = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp)arg).getDescriptor();
            this._frameTunnelMode = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp)arg).getFrameTunnelMode();
            this._macType = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp)arg).getMacType();
            this._radioInfo = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp)arg).getRadioInfo();
            this._discoveryType = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp)arg).getDiscoveryType();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp] \n" +
              "but was: " + arg
            );
        }
    }

    public BoardData getBoardData() {
        return _boardData;
    }
    
    public Descriptor getDescriptor() {
        return _descriptor;
    }
    
    public DiscoveryType getDiscoveryType() {
        return _discoveryType;
    }
    
    public FrameTunnelMode getFrameTunnelMode() {
        return _frameTunnelMode;
    }
    
    public java.lang.String getIpv4Addr() {
        return _ipv4Addr;
    }
    
    public DiscoveredWtpsKey getKey() {
        return _key;
    }
    
    public MacType getMacType() {
        return _macType;
    }
    
    public RadioInfo getRadioInfo() {
        return _radioInfo;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public DiscoveredWtpsBuilder setBoardData(BoardData value) {
        this._boardData = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setDescriptor(Descriptor value) {
        this._descriptor = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setDiscoveryType(DiscoveryType value) {
        this._discoveryType = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setFrameTunnelMode(FrameTunnelMode value) {
        this._frameTunnelMode = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setIpv4Addr(java.lang.String value) {
        this._ipv4Addr = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setKey(DiscoveredWtpsKey value) {
        this._key = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setMacType(MacType value) {
        this._macType = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder setRadioInfo(RadioInfo value) {
        this._radioInfo = value;
        return this;
    }
    
    public DiscoveredWtpsBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public DiscoveredWtpsBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> augmentationType) {
        this.augmentation.remove(augmentationType);
        return this;
    }

    public DiscoveredWtps build() {
        return new DiscoveredWtpsImpl(this);
    }

    private static final class DiscoveredWtpsImpl implements DiscoveredWtps {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps.class;
        }

        private final BoardData _boardData;
        private final Descriptor _descriptor;
        private final DiscoveryType _discoveryType;
        private final FrameTunnelMode _frameTunnelMode;
        private final java.lang.String _ipv4Addr;
        private final DiscoveredWtpsKey _key;
        private final MacType _macType;
        private final RadioInfo _radioInfo;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> augmentation = new HashMap<>();

        private DiscoveredWtpsImpl(DiscoveredWtpsBuilder base) {
            if (base.getKey() == null) {
                this._key = new DiscoveredWtpsKey(
                    base.getIpv4Addr()
                );
                this._ipv4Addr = base.getIpv4Addr();
            } else {
                this._key = base.getKey();
                this._ipv4Addr = _key.getIpv4Addr();
            }
            this._boardData = base.getBoardData();
            this._descriptor = base.getDescriptor();
            this._discoveryType = base.getDiscoveryType();
            this._frameTunnelMode = base.getFrameTunnelMode();
            this._macType = base.getMacType();
            this._radioInfo = base.getRadioInfo();
                switch (base.augmentation.size()) {
                case 0:
                    this.augmentation = Collections.emptyMap();
                    break;
                    case 1:
                        final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> e = base.augmentation.entrySet().iterator().next();
                        this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>>singletonMap(e.getKey(), e.getValue());
                    break;
                default :
                    this.augmentation = new HashMap<>(base.augmentation);
                }
        }

        @Override
        public BoardData getBoardData() {
            return _boardData;
        }
        
        @Override
        public Descriptor getDescriptor() {
            return _descriptor;
        }
        
        @Override
        public DiscoveryType getDiscoveryType() {
            return _discoveryType;
        }
        
        @Override
        public FrameTunnelMode getFrameTunnelMode() {
            return _frameTunnelMode;
        }
        
        @Override
        public java.lang.String getIpv4Addr() {
            return _ipv4Addr;
        }
        
        @Override
        public DiscoveredWtpsKey getKey() {
            return _key;
        }
        
        @Override
        public MacType getMacType() {
            return _macType;
        }
        
        @Override
        public RadioInfo getRadioInfo() {
            return _radioInfo;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_boardData == null) ? 0 : _boardData.hashCode());
            result = prime * result + ((_descriptor == null) ? 0 : _descriptor.hashCode());
            result = prime * result + ((_discoveryType == null) ? 0 : _discoveryType.hashCode());
            result = prime * result + ((_frameTunnelMode == null) ? 0 : _frameTunnelMode.hashCode());
            result = prime * result + ((_ipv4Addr == null) ? 0 : _ipv4Addr.hashCode());
            result = prime * result + ((_key == null) ? 0 : _key.hashCode());
            result = prime * result + ((_macType == null) ? 0 : _macType.hashCode());
            result = prime * result + ((_radioInfo == null) ? 0 : _radioInfo.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps other = (org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps)obj;
            if (_boardData == null) {
                if (other.getBoardData() != null) {
                    return false;
                }
            } else if(!_boardData.equals(other.getBoardData())) {
                return false;
            }
            if (_descriptor == null) {
                if (other.getDescriptor() != null) {
                    return false;
                }
            } else if(!_descriptor.equals(other.getDescriptor())) {
                return false;
            }
            if (_discoveryType == null) {
                if (other.getDiscoveryType() != null) {
                    return false;
                }
            } else if(!_discoveryType.equals(other.getDiscoveryType())) {
                return false;
            }
            if (_frameTunnelMode == null) {
                if (other.getFrameTunnelMode() != null) {
                    return false;
                }
            } else if(!_frameTunnelMode.equals(other.getFrameTunnelMode())) {
                return false;
            }
            if (_ipv4Addr == null) {
                if (other.getIpv4Addr() != null) {
                    return false;
                }
            } else if(!_ipv4Addr.equals(other.getIpv4Addr())) {
                return false;
            }
            if (_key == null) {
                if (other.getKey() != null) {
                    return false;
                }
            } else if(!_key.equals(other.getKey())) {
                return false;
            }
            if (_macType == null) {
                if (other.getMacType() != null) {
                    return false;
                }
            } else if(!_macType.equals(other.getMacType())) {
                return false;
            }
            if (_radioInfo == null) {
                if (other.getRadioInfo() != null) {
                    return false;
                }
            } else if(!_radioInfo.equals(other.getRadioInfo())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                DiscoveredWtpsImpl otherImpl = (DiscoveredWtpsImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("DiscoveredWtps [");
            boolean first = true;
        
            if (_boardData != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_boardData=");
                builder.append(_boardData);
             }
            if (_descriptor != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_descriptor=");
                builder.append(_descriptor);
             }
            if (_discoveryType != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_discoveryType=");
                builder.append(_discoveryType);
             }
            if (_frameTunnelMode != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_frameTunnelMode=");
                builder.append(_frameTunnelMode);
             }
            if (_ipv4Addr != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_ipv4Addr=");
                builder.append(_ipv4Addr);
             }
            if (_key != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_key=");
                builder.append(_key);
             }
            if (_macType != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_macType=");
                builder.append(_macType);
             }
            if (_radioInfo != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_radioInfo=");
                builder.append(_radioInfo);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
