package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container frame-tunnel-mode {
 *     leaf rsvd {
 *         type uint8;
 *     }
 *     leaf bit-n {
 *         type boolean;
 *     }
 *     leaf bit-e {
 *         type boolean;
 *     }
 *     leaf bit-l {
 *         type boolean;
 *     }
 *     leaf bit-r {
 *         type boolean;
 *     }
 *     uses wtp-frame-tunnel-mode;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/discovered-wtp/frame-tunnel-mode&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelModeBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelModeBuilder
 *
 */
public interface FrameTunnelMode
    extends
    ChildOf<DiscoveredWtp>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>,
    WtpFrameTunnelMode
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","frame-tunnel-mode"));


}

