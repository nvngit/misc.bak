package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * AC Information Sub-element
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping ac-info-sub-element {
 *     leaf vendorid {
 *         type vendor-id;
 *     }
 *     leaf type {
 *         type uint16;
 *     }
 *     leaf length {
 *         type uint16;
 *     }
 *     leaf data {
 *         type binary;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/ac-info-sub-element&lt;/i&gt;
 *
 */
public interface AcInfoSubElement
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","ac-info-sub-element"));

    VendorId getVendorid();
    
    java.lang.Integer getType();
    
    java.lang.Integer getLength();
    
    byte[] getData();

}

