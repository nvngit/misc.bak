package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import com.google.common.collect.Range;
import java.util.Collections;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.VendorId;
import java.util.Map;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import com.google.common.collect.ImmutableList;
import java.math.BigInteger;
import java.util.List;
import java.util.Arrays;
import org.opendaylight.yangtools.yang.binding.Augmentation;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData
 *
 */
public class BoardDataBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData> {

    private java.lang.Integer _length;
    private static List<Range<BigInteger>> _length_range;
    private java.lang.Integer _type;
    private static List<Range<BigInteger>> _type_range;
    private byte[] _value;
    private VendorId _vendorid;
    private static List<Range<BigInteger>> _vendorid_range;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> augmentation = new HashMap<>();

    public BoardDataBuilder() {
    }
    public BoardDataBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardData arg) {
        this._vendorid = arg.getVendorid();
        this._type = arg.getType();
        this._length = arg.getLength();
        this._value = arg.getValue();
    }
    public BoardDataBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe arg) {
        this._type = arg.getType();
        this._length = arg.getLength();
        this._value = arg.getValue();
    }

    public BoardDataBuilder(BoardData base) {
        this._length = base.getLength();
        this._type = base.getType();
        this._value = base.getValue();
        this._vendorid = base.getVendorid();
        if (base instanceof BoardDataImpl) {
            BoardDataImpl _impl = (BoardDataImpl) base;
            this.augmentation = new HashMap<>(_impl.augmentation);
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe</li>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardData</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe) {
            this._type = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe)arg).getType();
            this._length = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe)arg).getLength();
            this._value = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe)arg).getValue();
            isValidArg = true;
        }
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardData) {
            this._vendorid = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardData)arg).getVendorid();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardDataSe, org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardData] \n" +
              "but was: " + arg
            );
        }
    }

    public java.lang.Integer getLength() {
        return _length;
    }
    
    public java.lang.Integer getType() {
        return _type;
    }
    
    public byte[] getValue() {
        return _value == null ? null : _value.clone();
    }
    
    public VendorId getVendorid() {
        return _vendorid;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public BoardDataBuilder setLength(java.lang.Integer value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _length_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _length_range));
            }
        }
        this._length = value;
        return this;
    }
    public static List<Range<BigInteger>> _length_range() {
        if (_length_range == null) {
            synchronized (BoardDataBuilder.class) {
                if (_length_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ONE, BigInteger.valueOf(1024L)));
                    _length_range = builder.build();
                }
            }
        }
        return _length_range;
    }
    
    public BoardDataBuilder setType(java.lang.Integer value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _type_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _type_range));
            }
        }
        this._type = value;
        return this;
    }
    public static List<Range<BigInteger>> _type_range() {
        if (_type_range == null) {
            synchronized (BoardDataBuilder.class) {
                if (_type_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(4L)));
                    _type_range = builder.build();
                }
            }
        }
        return _type_range;
    }
    
    public BoardDataBuilder setValue(byte[] value) {
        this._value = value;
        return this;
    }
    
    public BoardDataBuilder setVendorid(VendorId value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value.getValue());
            boolean isValidRange = false;
            for (Range<BigInteger> r : _vendorid_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _vendorid_range));
            }
        }
        this._vendorid = value;
        return this;
    }
    public static List<Range<BigInteger>> _vendorid_range() {
        if (_vendorid_range == null) {
            synchronized (BoardDataBuilder.class) {
                if (_vendorid_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(4294967295L)));
                    _vendorid_range = builder.build();
                }
            }
        }
        return _vendorid_range;
    }
    
    public BoardDataBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public BoardDataBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> augmentationType) {
        this.augmentation.remove(augmentationType);
        return this;
    }

    public BoardData build() {
        return new BoardDataImpl(this);
    }

    private static final class BoardDataImpl implements BoardData {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData.class;
        }

        private final java.lang.Integer _length;
        private final java.lang.Integer _type;
        private final byte[] _value;
        private final VendorId _vendorid;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> augmentation = new HashMap<>();

        private BoardDataImpl(BoardDataBuilder base) {
            this._length = base.getLength();
            this._type = base.getType();
            this._value = base.getValue();
            this._vendorid = base.getVendorid();
                switch (base.augmentation.size()) {
                case 0:
                    this.augmentation = Collections.emptyMap();
                    break;
                    case 1:
                        final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> e = base.augmentation.entrySet().iterator().next();
                        this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>>singletonMap(e.getKey(), e.getValue());
                    break;
                default :
                    this.augmentation = new HashMap<>(base.augmentation);
                }
        }

        @Override
        public java.lang.Integer getLength() {
            return _length;
        }
        
        @Override
        public java.lang.Integer getType() {
            return _type;
        }
        
        @Override
        public byte[] getValue() {
            return _value == null ? null : _value.clone();
        }
        
        @Override
        public VendorId getVendorid() {
            return _vendorid;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_length == null) ? 0 : _length.hashCode());
            result = prime * result + ((_type == null) ? 0 : _type.hashCode());
            result = prime * result + ((_value == null) ? 0 : Arrays.hashCode(_value));
            result = prime * result + ((_vendorid == null) ? 0 : _vendorid.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData other = (org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData)obj;
            if (_length == null) {
                if (other.getLength() != null) {
                    return false;
                }
            } else if(!_length.equals(other.getLength())) {
                return false;
            }
            if (_type == null) {
                if (other.getType() != null) {
                    return false;
                }
            } else if(!_type.equals(other.getType())) {
                return false;
            }
            if (_value == null) {
                if (other.getValue() != null) {
                    return false;
                }
            } else if(!Arrays.equals(_value, other.getValue())) {
                return false;
            }
            if (_vendorid == null) {
                if (other.getVendorid() != null) {
                    return false;
                }
            } else if(!_vendorid.equals(other.getVendorid())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                BoardDataImpl otherImpl = (BoardDataImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("BoardData [");
            boolean first = true;
        
            if (_length != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_length=");
                builder.append(_length);
             }
            if (_type != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_type=");
                builder.append(_type);
             }
            if (_value != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_value=");
                builder.append(Arrays.toString(_value));
             }
            if (_vendorid != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_vendorid=");
                builder.append(_vendorid);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
