package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpDescriptor;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container descriptor {
 *     leaf max-radios {
 *         type uint8;
 *     }
 *     leaf radios-in-use {
 *         type uint8;
 *     }
 *     leaf num-encrypt {
 *         type uint8;
 *     }
 *     leaf vendorid {
 *         type vendor-id;
 *     }
 *     leaf type {
 *         type uint16;
 *     }
 *     leaf length {
 *         type uint16;
 *     }
 *     leaf value {
 *         type binary;
 *     }
 *     leaf resvd {
 *         type uint8;
 *     }
 *     leaf wbid {
 *         type uint8;
 *     }
 *     leaf capabilities {
 *         type uint16;
 *     }
 *     uses wtp-descriptor;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/discovered-wtp/descriptor&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.DescriptorBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.DescriptorBuilder
 *
 */
public interface Descriptor
    extends
    ChildOf<DiscoveredWtp>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.Descriptor>,
    WtpDescriptor
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","descriptor"));


}

