package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import com.google.common.collect.Range;
import java.util.Collections;
import java.util.Map;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import com.google.common.collect.ImmutableList;
import java.math.BigInteger;
import java.util.List;
import org.opendaylight.yangtools.yang.binding.Augmentation;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode
 *
 */
public class FrameTunnelModeBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode> {

    private java.lang.Short _rsvd;
    private static List<Range<BigInteger>> _rsvd_range;
    private java.lang.Boolean _bitE;
    private java.lang.Boolean _bitL;
    private java.lang.Boolean _bitN;
    private java.lang.Boolean _bitR;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> augmentation = new HashMap<>();

    public FrameTunnelModeBuilder() {
    }
    public FrameTunnelModeBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode arg) {
        this._rsvd = arg.getRsvd();
        this._bitN = arg.isBitN();
        this._bitE = arg.isBitE();
        this._bitL = arg.isBitL();
        this._bitR = arg.isBitR();
    }

    public FrameTunnelModeBuilder(FrameTunnelMode base) {
        this._rsvd = base.getRsvd();
        this._bitE = base.isBitE();
        this._bitL = base.isBitL();
        this._bitN = base.isBitN();
        this._bitR = base.isBitR();
        if (base instanceof FrameTunnelModeImpl) {
            FrameTunnelModeImpl _impl = (FrameTunnelModeImpl) base;
            this.augmentation = new HashMap<>(_impl.augmentation);
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode) {
            this._rsvd = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode)arg).getRsvd();
            this._bitN = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode)arg).isBitN();
            this._bitE = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode)arg).isBitE();
            this._bitL = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode)arg).isBitL();
            this._bitR = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode)arg).isBitR();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpFrameTunnelMode] \n" +
              "but was: " + arg
            );
        }
    }

    public java.lang.Short getRsvd() {
        return _rsvd;
    }
    
    public java.lang.Boolean isBitE() {
        return _bitE;
    }
    
    public java.lang.Boolean isBitL() {
        return _bitL;
    }
    
    public java.lang.Boolean isBitN() {
        return _bitN;
    }
    
    public java.lang.Boolean isBitR() {
        return _bitR;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public FrameTunnelModeBuilder setRsvd(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _rsvd_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _rsvd_range));
            }
        }
        this._rsvd = value;
        return this;
    }
    public static List<Range<BigInteger>> _rsvd_range() {
        if (_rsvd_range == null) {
            synchronized (FrameTunnelModeBuilder.class) {
                if (_rsvd_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(15L)));
                    _rsvd_range = builder.build();
                }
            }
        }
        return _rsvd_range;
    }
    
    public FrameTunnelModeBuilder setBitE(java.lang.Boolean value) {
        this._bitE = value;
        return this;
    }
    
    public FrameTunnelModeBuilder setBitL(java.lang.Boolean value) {
        this._bitL = value;
        return this;
    }
    
    public FrameTunnelModeBuilder setBitN(java.lang.Boolean value) {
        this._bitN = value;
        return this;
    }
    
    public FrameTunnelModeBuilder setBitR(java.lang.Boolean value) {
        this._bitR = value;
        return this;
    }
    
    public FrameTunnelModeBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public FrameTunnelModeBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> augmentationType) {
        this.augmentation.remove(augmentationType);
        return this;
    }

    public FrameTunnelMode build() {
        return new FrameTunnelModeImpl(this);
    }

    private static final class FrameTunnelModeImpl implements FrameTunnelMode {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode.class;
        }

        private final java.lang.Short _rsvd;
        private final java.lang.Boolean _bitE;
        private final java.lang.Boolean _bitL;
        private final java.lang.Boolean _bitN;
        private final java.lang.Boolean _bitR;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> augmentation = new HashMap<>();

        private FrameTunnelModeImpl(FrameTunnelModeBuilder base) {
            this._rsvd = base.getRsvd();
            this._bitE = base.isBitE();
            this._bitL = base.isBitL();
            this._bitN = base.isBitN();
            this._bitR = base.isBitR();
                switch (base.augmentation.size()) {
                case 0:
                    this.augmentation = Collections.emptyMap();
                    break;
                    case 1:
                        final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> e = base.augmentation.entrySet().iterator().next();
                        this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>>singletonMap(e.getKey(), e.getValue());
                    break;
                default :
                    this.augmentation = new HashMap<>(base.augmentation);
                }
        }

        @Override
        public java.lang.Short getRsvd() {
            return _rsvd;
        }
        
        @Override
        public java.lang.Boolean isBitE() {
            return _bitE;
        }
        
        @Override
        public java.lang.Boolean isBitL() {
            return _bitL;
        }
        
        @Override
        public java.lang.Boolean isBitN() {
            return _bitN;
        }
        
        @Override
        public java.lang.Boolean isBitR() {
            return _bitR;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_rsvd == null) ? 0 : _rsvd.hashCode());
            result = prime * result + ((_bitE == null) ? 0 : _bitE.hashCode());
            result = prime * result + ((_bitL == null) ? 0 : _bitL.hashCode());
            result = prime * result + ((_bitN == null) ? 0 : _bitN.hashCode());
            result = prime * result + ((_bitR == null) ? 0 : _bitR.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode other = (org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode)obj;
            if (_rsvd == null) {
                if (other.getRsvd() != null) {
                    return false;
                }
            } else if(!_rsvd.equals(other.getRsvd())) {
                return false;
            }
            if (_bitE == null) {
                if (other.isBitE() != null) {
                    return false;
                }
            } else if(!_bitE.equals(other.isBitE())) {
                return false;
            }
            if (_bitL == null) {
                if (other.isBitL() != null) {
                    return false;
                }
            } else if(!_bitL.equals(other.isBitL())) {
                return false;
            }
            if (_bitN == null) {
                if (other.isBitN() != null) {
                    return false;
                }
            } else if(!_bitN.equals(other.isBitN())) {
                return false;
            }
            if (_bitR == null) {
                if (other.isBitR() != null) {
                    return false;
                }
            } else if(!_bitR.equals(other.isBitR())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                FrameTunnelModeImpl otherImpl = (FrameTunnelModeImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.FrameTunnelMode>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("FrameTunnelMode [");
            boolean first = true;
        
            if (_rsvd != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_rsvd=");
                builder.append(_rsvd);
             }
            if (_bitE != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_bitE=");
                builder.append(_bitE);
             }
            if (_bitL != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_bitL=");
                builder.append(_bitL);
             }
            if (_bitN != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_bitN=");
                builder.append(_bitN);
             }
            if (_bitR != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_bitR=");
                builder.append(_bitR);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
