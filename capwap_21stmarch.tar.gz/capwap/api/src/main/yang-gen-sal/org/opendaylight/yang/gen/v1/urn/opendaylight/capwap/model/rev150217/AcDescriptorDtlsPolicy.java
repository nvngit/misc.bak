package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * AC Descriptor DTLS Policy
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping ac-descriptor-dtls-policy {
 *     leaf rsvd {
 *         type uint8;
 *     }
 *     leaf D {
 *         type boolean;
 *     }
 *     leaf C {
 *         type boolean;
 *     }
 *     leaf R {
 *         type boolean;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/ac-descriptor-dtls-policy&lt;/i&gt;
 *
 */
public interface AcDescriptorDtlsPolicy
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","ac-descriptor-dtls-policy"));

    java.lang.Short getRsvd();
    
    java.lang.Boolean isD();
    
    java.lang.Boolean isC();
    
    java.lang.Boolean isR();

}

