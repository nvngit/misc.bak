package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * Capwap Header
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping capwap-header {
 *     leaf version {
 *         type capwap-version;
 *     }
 *     leaf type {
 *         type capwap-pkt-type;
 *     }
 *     leaf hlen {
 *         type capwap-header-hlen;
 *     }
 *     leaf rid {
 *         type capwap-header-rid;
 *     }
 *     leaf t-flag {
 *         type boolean;
 *     }
 *     leaf f-flag {
 *         type boolean;
 *     }
 *     leaf l-flag {
 *         type boolean;
 *     }
 *     leaf w-flag {
 *         type boolean;
 *     }
 *     leaf m-flag {
 *         type boolean;
 *     }
 *     leaf k-flag {
 *         type boolean;
 *     }
 *     leaf flag {
 *         type capwap-header-flag;
 *     }
 *     leaf fragmentid {
 *         type uint16;
 *     }
 *     leaf fo {
 *         type capwap-header-fragmentoffset;
 *     }
 *     leaf rsvd {
 *         type capwap-header-rsvd;
 *     }
 *     leaf length {
 *         type uint8;
 *     }
 *     leaf value {
 *         type binary;
 *     }
 *     leaf wsi-length {
 *         type uint8;
 *     }
 *     leaf wsi-value {
 *         type binary;
 *     }
 *     leaf payload {
 *         type binary;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/capwap-header&lt;/i&gt;
 *
 */
public interface CapwapHeader
    extends
    DataObject,
    RadioMacAddr,
    WirelessSpecificInfo,
    CapwapPreamble
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","capwap-header"));

    CapwapHeaderHlen getHlen();
    
    CapwapHeaderRid getRid();
    
    /**
     * T Flag
     *
     */
    java.lang.Boolean isTFlag();
    
    /**
     * F Flag
     *
     */
    java.lang.Boolean isFFlag();
    
    /**
     * L Flag
     *
     */
    java.lang.Boolean isLFlag();
    
    /**
     * W Flag
     *
     */
    java.lang.Boolean isWFlag();
    
    /**
     * M Flag
     *
     */
    java.lang.Boolean isMFlag();
    
    /**
     * K Flag
     *
     */
    java.lang.Boolean isKFlag();
    
    CapwapHeaderFlag getFlag();
    
    /**
     * Fragment ID
     *
     */
    java.lang.Integer getFragmentid();
    
    /**
     * Fragment Offset
     *
     */
    CapwapHeaderFragmentoffset getFo();
    
    /**
     * RSVD
     *
     */
    CapwapHeaderRsvd getRsvd();
    
    /**
     * Payload
     *
     */
    byte[] getPayload();

}

