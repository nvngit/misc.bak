package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * WTP Board Data Sub-Element
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping wtp-board-data-se {
 *     leaf type {
 *         type uint16;
 *     }
 *     leaf length {
 *         type uint16;
 *     }
 *     leaf value {
 *         type binary;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/wtp-board-data-se&lt;/i&gt;
 *
 */
public interface WtpBoardDataSe
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","wtp-board-data-se"));

    java.lang.Integer getType();
    
    java.lang.Integer getLength();
    
    byte[] getValue();

}

