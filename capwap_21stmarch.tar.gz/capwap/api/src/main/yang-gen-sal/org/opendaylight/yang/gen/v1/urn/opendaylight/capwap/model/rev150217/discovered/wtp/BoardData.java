package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpBoardData;
import org.opendaylight.yangtools.yang.binding.Augmentable;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * container board-data {
 *     leaf vendorid {
 *         type vendor-id;
 *     }
 *     leaf type {
 *         type uint16;
 *     }
 *     leaf length {
 *         type uint16;
 *     }
 *     leaf value {
 *         type binary;
 *     }
 *     uses wtp-board-data;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/discovered-wtp/board-data&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardDataBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardDataBuilder
 *
 */
public interface BoardData
    extends
    ChildOf<DiscoveredWtp>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.BoardData>,
    WtpBoardData
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","board-data"));


}

