package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp;
import com.google.common.collect.Range;
import java.util.Collections;
import java.util.Map;
import org.opendaylight.yangtools.yang.binding.DataObject;
import java.util.HashMap;
import org.opendaylight.yangtools.concepts.Builder;
import com.google.common.collect.ImmutableList;
import java.math.BigInteger;
import java.util.List;
import org.opendaylight.yangtools.yang.binding.Augmentation;


/**
 * Class that builds {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo} instances.
 *
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo
 *
 */
public class RadioInfoBuilder implements Builder <org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo> {

    private java.lang.Short _radioId;
    private static List<Range<BigInteger>> _radioId_range;
    private java.lang.Short _rsvd;
    private static List<Range<BigInteger>> _rsvd_range;
    private java.lang.Integer _rsvd1;
    private static List<Range<BigInteger>> _rsvd1_range;
    private java.lang.Short _rsvd2;
    private static List<Range<BigInteger>> _rsvd2_range;
    private java.lang.Short _rsvd3;
    private static List<Range<BigInteger>> _rsvd3_range;
    private java.lang.Boolean _typeA;
    private java.lang.Boolean _typeB;
    private java.lang.Boolean _typeG;
    private java.lang.Boolean _typeN;

    Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> augmentation = new HashMap<>();

    public RadioInfoBuilder() {
    }
    public RadioInfoBuilder(org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo arg) {
        this._radioId = arg.getRadioId();
        this._rsvd = arg.getRsvd();
        this._rsvd1 = arg.getRsvd1();
        this._rsvd2 = arg.getRsvd2();
        this._rsvd3 = arg.getRsvd3();
        this._typeN = arg.isTypeN();
        this._typeG = arg.isTypeG();
        this._typeA = arg.isTypeA();
        this._typeB = arg.isTypeB();
    }

    public RadioInfoBuilder(RadioInfo base) {
        this._radioId = base.getRadioId();
        this._rsvd = base.getRsvd();
        this._rsvd1 = base.getRsvd1();
        this._rsvd2 = base.getRsvd2();
        this._rsvd3 = base.getRsvd3();
        this._typeA = base.isTypeA();
        this._typeB = base.isTypeB();
        this._typeG = base.isTypeG();
        this._typeN = base.isTypeN();
        if (base instanceof RadioInfoImpl) {
            RadioInfoImpl _impl = (RadioInfoImpl) base;
            this.augmentation = new HashMap<>(_impl.augmentation);
        }
    }

    /**
     *Set fields from given grouping argument. Valid argument is instance of one of following types:
     * <ul>
     * <li>org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo</li>
     * </ul>
     *
     * @param arg grouping object
     * @throws IllegalArgumentException if given argument is none of valid types
    */
    public void fieldsFrom(DataObject arg) {
        boolean isValidArg = false;
        if (arg instanceof org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo) {
            this._radioId = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).getRadioId();
            this._rsvd = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).getRsvd();
            this._rsvd1 = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).getRsvd1();
            this._rsvd2 = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).getRsvd2();
            this._rsvd3 = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).getRsvd3();
            this._typeN = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).isTypeN();
            this._typeG = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).isTypeG();
            this._typeA = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).isTypeA();
            this._typeB = ((org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo)arg).isTypeB();
            isValidArg = true;
        }
        if (!isValidArg) {
            throw new IllegalArgumentException(
              "expected one of: [org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.WtpRadioInfo] \n" +
              "but was: " + arg
            );
        }
    }

    public java.lang.Short getRadioId() {
        return _radioId;
    }
    
    public java.lang.Short getRsvd() {
        return _rsvd;
    }
    
    public java.lang.Integer getRsvd1() {
        return _rsvd1;
    }
    
    public java.lang.Short getRsvd2() {
        return _rsvd2;
    }
    
    public java.lang.Short getRsvd3() {
        return _rsvd3;
    }
    
    public java.lang.Boolean isTypeA() {
        return _typeA;
    }
    
    public java.lang.Boolean isTypeB() {
        return _typeB;
    }
    
    public java.lang.Boolean isTypeG() {
        return _typeG;
    }
    
    public java.lang.Boolean isTypeN() {
        return _typeN;
    }
    
    @SuppressWarnings("unchecked")
    public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> E getAugmentation(java.lang.Class<E> augmentationType) {
        if (augmentationType == null) {
            throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
        }
        return (E) augmentation.get(augmentationType);
    }

    public RadioInfoBuilder setRadioId(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _radioId_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _radioId_range));
            }
        }
        this._radioId = value;
        return this;
    }
    public static List<Range<BigInteger>> _radioId_range() {
        if (_radioId_range == null) {
            synchronized (RadioInfoBuilder.class) {
                if (_radioId_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ONE, BigInteger.valueOf(31L)));
                    _radioId_range = builder.build();
                }
            }
        }
        return _radioId_range;
    }
    
    public RadioInfoBuilder setRsvd(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _rsvd_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _rsvd_range));
            }
        }
        this._rsvd = value;
        return this;
    }
    public static List<Range<BigInteger>> _rsvd_range() {
        if (_rsvd_range == null) {
            synchronized (RadioInfoBuilder.class) {
                if (_rsvd_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(7L)));
                    _rsvd_range = builder.build();
                }
            }
        }
        return _rsvd_range;
    }
    
    public RadioInfoBuilder setRsvd1(java.lang.Integer value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _rsvd1_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _rsvd1_range));
            }
        }
        this._rsvd1 = value;
        return this;
    }
    public static List<Range<BigInteger>> _rsvd1_range() {
        if (_rsvd1_range == null) {
            synchronized (RadioInfoBuilder.class) {
                if (_rsvd1_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(65535L)));
                    _rsvd1_range = builder.build();
                }
            }
        }
        return _rsvd1_range;
    }
    
    public RadioInfoBuilder setRsvd2(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _rsvd2_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _rsvd2_range));
            }
        }
        this._rsvd2 = value;
        return this;
    }
    public static List<Range<BigInteger>> _rsvd2_range() {
        if (_rsvd2_range == null) {
            synchronized (RadioInfoBuilder.class) {
                if (_rsvd2_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(255L)));
                    _rsvd2_range = builder.build();
                }
            }
        }
        return _rsvd2_range;
    }
    
    public RadioInfoBuilder setRsvd3(java.lang.Short value) {
        if (value != null) {
            BigInteger _constraint = BigInteger.valueOf(value);
            boolean isValidRange = false;
            for (Range<BigInteger> r : _rsvd3_range()) {
                if (r.contains(_constraint)) {
                    isValidRange = true;
                }
            }
            if (!isValidRange) {
                throw new IllegalArgumentException(String.format("Invalid range: %s, expected: %s.", value, _rsvd3_range));
            }
        }
        this._rsvd3 = value;
        return this;
    }
    public static List<Range<BigInteger>> _rsvd3_range() {
        if (_rsvd3_range == null) {
            synchronized (RadioInfoBuilder.class) {
                if (_rsvd3_range == null) {
                    ImmutableList.Builder<Range<BigInteger>> builder = ImmutableList.builder();
                    builder.add(Range.closed(BigInteger.ZERO, BigInteger.valueOf(15L)));
                    _rsvd3_range = builder.build();
                }
            }
        }
        return _rsvd3_range;
    }
    
    public RadioInfoBuilder setTypeA(java.lang.Boolean value) {
        this._typeA = value;
        return this;
    }
    
    public RadioInfoBuilder setTypeB(java.lang.Boolean value) {
        this._typeB = value;
        return this;
    }
    
    public RadioInfoBuilder setTypeG(java.lang.Boolean value) {
        this._typeG = value;
        return this;
    }
    
    public RadioInfoBuilder setTypeN(java.lang.Boolean value) {
        this._typeN = value;
        return this;
    }
    
    public RadioInfoBuilder addAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> augmentationType, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo> augmentation) {
        if (augmentation == null) {
            return removeAugmentation(augmentationType);
        }
        this.augmentation.put(augmentationType, augmentation);
        return this;
    }
    
    public RadioInfoBuilder removeAugmentation(java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> augmentationType) {
        this.augmentation.remove(augmentationType);
        return this;
    }

    public RadioInfo build() {
        return new RadioInfoImpl(this);
    }

    private static final class RadioInfoImpl implements RadioInfo {

        public java.lang.Class<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo> getImplementedInterface() {
            return org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo.class;
        }

        private final java.lang.Short _radioId;
        private final java.lang.Short _rsvd;
        private final java.lang.Integer _rsvd1;
        private final java.lang.Short _rsvd2;
        private final java.lang.Short _rsvd3;
        private final java.lang.Boolean _typeA;
        private final java.lang.Boolean _typeB;
        private final java.lang.Boolean _typeG;
        private final java.lang.Boolean _typeN;

        private Map<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> augmentation = new HashMap<>();

        private RadioInfoImpl(RadioInfoBuilder base) {
            this._radioId = base.getRadioId();
            this._rsvd = base.getRsvd();
            this._rsvd1 = base.getRsvd1();
            this._rsvd2 = base.getRsvd2();
            this._rsvd3 = base.getRsvd3();
            this._typeA = base.isTypeA();
            this._typeB = base.isTypeB();
            this._typeG = base.isTypeG();
            this._typeN = base.isTypeN();
                switch (base.augmentation.size()) {
                case 0:
                    this.augmentation = Collections.emptyMap();
                    break;
                    case 1:
                        final Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> e = base.augmentation.entrySet().iterator().next();
                        this.augmentation = Collections.<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>>singletonMap(e.getKey(), e.getValue());
                    break;
                default :
                    this.augmentation = new HashMap<>(base.augmentation);
                }
        }

        @Override
        public java.lang.Short getRadioId() {
            return _radioId;
        }
        
        @Override
        public java.lang.Short getRsvd() {
            return _rsvd;
        }
        
        @Override
        public java.lang.Integer getRsvd1() {
            return _rsvd1;
        }
        
        @Override
        public java.lang.Short getRsvd2() {
            return _rsvd2;
        }
        
        @Override
        public java.lang.Short getRsvd3() {
            return _rsvd3;
        }
        
        @Override
        public java.lang.Boolean isTypeA() {
            return _typeA;
        }
        
        @Override
        public java.lang.Boolean isTypeB() {
            return _typeB;
        }
        
        @Override
        public java.lang.Boolean isTypeG() {
            return _typeG;
        }
        
        @Override
        public java.lang.Boolean isTypeN() {
            return _typeN;
        }
        
        @SuppressWarnings("unchecked")
        @Override
        public <E extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> E getAugmentation(java.lang.Class<E> augmentationType) {
            if (augmentationType == null) {
                throw new IllegalArgumentException("Augmentation Type reference cannot be NULL!");
            }
            return (E) augmentation.get(augmentationType);
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((_radioId == null) ? 0 : _radioId.hashCode());
            result = prime * result + ((_rsvd == null) ? 0 : _rsvd.hashCode());
            result = prime * result + ((_rsvd1 == null) ? 0 : _rsvd1.hashCode());
            result = prime * result + ((_rsvd2 == null) ? 0 : _rsvd2.hashCode());
            result = prime * result + ((_rsvd3 == null) ? 0 : _rsvd3.hashCode());
            result = prime * result + ((_typeA == null) ? 0 : _typeA.hashCode());
            result = prime * result + ((_typeB == null) ? 0 : _typeB.hashCode());
            result = prime * result + ((_typeG == null) ? 0 : _typeG.hashCode());
            result = prime * result + ((_typeN == null) ? 0 : _typeN.hashCode());
            result = prime * result + ((augmentation == null) ? 0 : augmentation.hashCode());
            return result;
        }

        @Override
        public boolean equals(java.lang.Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof DataObject)) {
                return false;
            }
            if (!org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo.class.equals(((DataObject)obj).getImplementedInterface())) {
                return false;
            }
            org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo other = (org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo)obj;
            if (_radioId == null) {
                if (other.getRadioId() != null) {
                    return false;
                }
            } else if(!_radioId.equals(other.getRadioId())) {
                return false;
            }
            if (_rsvd == null) {
                if (other.getRsvd() != null) {
                    return false;
                }
            } else if(!_rsvd.equals(other.getRsvd())) {
                return false;
            }
            if (_rsvd1 == null) {
                if (other.getRsvd1() != null) {
                    return false;
                }
            } else if(!_rsvd1.equals(other.getRsvd1())) {
                return false;
            }
            if (_rsvd2 == null) {
                if (other.getRsvd2() != null) {
                    return false;
                }
            } else if(!_rsvd2.equals(other.getRsvd2())) {
                return false;
            }
            if (_rsvd3 == null) {
                if (other.getRsvd3() != null) {
                    return false;
                }
            } else if(!_rsvd3.equals(other.getRsvd3())) {
                return false;
            }
            if (_typeA == null) {
                if (other.isTypeA() != null) {
                    return false;
                }
            } else if(!_typeA.equals(other.isTypeA())) {
                return false;
            }
            if (_typeB == null) {
                if (other.isTypeB() != null) {
                    return false;
                }
            } else if(!_typeB.equals(other.isTypeB())) {
                return false;
            }
            if (_typeG == null) {
                if (other.isTypeG() != null) {
                    return false;
                }
            } else if(!_typeG.equals(other.isTypeG())) {
                return false;
            }
            if (_typeN == null) {
                if (other.isTypeN() != null) {
                    return false;
                }
            } else if(!_typeN.equals(other.isTypeN())) {
                return false;
            }
            if (getClass() == obj.getClass()) {
                // Simple case: we are comparing against self
                RadioInfoImpl otherImpl = (RadioInfoImpl) obj;
                if (augmentation == null) {
                    if (otherImpl.augmentation != null) {
                        return false;
                    }
                } else if(!augmentation.equals(otherImpl.augmentation)) {
                    return false;
                }
            } else {
                // Hard case: compare our augments with presence there...
                for (Map.Entry<java.lang.Class<? extends Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>>, Augmentation<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.discovered.wtp.RadioInfo>> e : augmentation.entrySet()) {
                    if (!e.getValue().equals(other.getAugmentation(e.getKey()))) {
                        return false;
                    }
                }
                // .. and give the other one the chance to do the same
                if (!obj.equals(this)) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public java.lang.String toString() {
            java.lang.StringBuilder builder = new java.lang.StringBuilder ("RadioInfo [");
            boolean first = true;
        
            if (_radioId != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_radioId=");
                builder.append(_radioId);
             }
            if (_rsvd != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_rsvd=");
                builder.append(_rsvd);
             }
            if (_rsvd1 != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_rsvd1=");
                builder.append(_rsvd1);
             }
            if (_rsvd2 != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_rsvd2=");
                builder.append(_rsvd2);
             }
            if (_rsvd3 != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_rsvd3=");
                builder.append(_rsvd3);
             }
            if (_typeA != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_typeA=");
                builder.append(_typeA);
             }
            if (_typeB != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_typeB=");
                builder.append(_typeB);
             }
            if (_typeG != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_typeG=");
                builder.append(_typeG);
             }
            if (_typeN != null) {
                if (first) {
                    first = false;
                } else {
                    builder.append(", ");
                }
                builder.append("_typeN=");
                builder.append(_typeN);
             }
            if (first) {
                first = false;
            } else {
                builder.append(", ");
            }
            builder.append("augmentation=");
            builder.append(augmentation.values());
            return builder.append(']').toString();
        }
    }

}
