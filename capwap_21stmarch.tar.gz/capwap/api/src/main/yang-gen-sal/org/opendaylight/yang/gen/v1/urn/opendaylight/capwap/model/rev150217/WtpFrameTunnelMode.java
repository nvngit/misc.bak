package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * WTP Frame Tunnel Mode Message Element
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping wtp-frame-tunnel-mode {
 *     leaf rsvd {
 *         type uint8;
 *     }
 *     leaf bit-n {
 *         type boolean;
 *     }
 *     leaf bit-e {
 *         type boolean;
 *     }
 *     leaf bit-l {
 *         type boolean;
 *     }
 *     leaf bit-r {
 *         type boolean;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/wtp-frame-tunnel-mode&lt;/i&gt;
 *
 */
public interface WtpFrameTunnelMode
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","wtp-frame-tunnel-mode"));

    java.lang.Short getRsvd();
    
    java.lang.Boolean isBitN();
    
    java.lang.Boolean isBitE();
    
    java.lang.Boolean isBitL();
    
    java.lang.Boolean isBitR();

}

