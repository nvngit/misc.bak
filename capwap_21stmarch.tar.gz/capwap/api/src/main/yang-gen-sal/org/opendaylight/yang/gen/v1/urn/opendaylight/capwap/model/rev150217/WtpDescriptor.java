package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * WTP Descriptor Message Element
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping wtp-descriptor {
 *     leaf max-radios {
 *         type uint8;
 *     }
 *     leaf radios-in-use {
 *         type uint8;
 *     }
 *     leaf num-encrypt {
 *         type uint8;
 *     }
 *     leaf vendorid {
 *         type vendor-id;
 *     }
 *     leaf type {
 *         type uint16;
 *     }
 *     leaf length {
 *         type uint16;
 *     }
 *     leaf value {
 *         type binary;
 *     }
 *     leaf resvd {
 *         type uint8;
 *     }
 *     leaf wbid {
 *         type uint8;
 *     }
 *     leaf capabilities {
 *         type uint16;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/wtp-descriptor&lt;/i&gt;
 *
 */
public interface WtpDescriptor
    extends
    DataObject,
    WtpDescriptorSe,
    WtpEncryptionSe
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","wtp-descriptor"));

    java.lang.Short getMaxRadios();
    
    java.lang.Short getRadiosInUse();
    
    java.lang.Short getNumEncrypt();

}

