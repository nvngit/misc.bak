package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * AC Descriptor
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping ac-descriptor {
 *     leaf length {
 *         type uint8;
 *     }
 *     leaf value {
 *         type binary;
 *     }
 *     leaf stations {
 *         type uint16;
 *     }
 *     leaf limit {
 *         type uint16;
 *     }
 *     leaf active-wtp {
 *         type uint16;
 *     }
 *     leaf max-wtp {
 *         type uint16;
 *     }
 *     leaf security {
 *         type uint8;
 *     }
 *     leaf r-mac-field {
 *         type uint8;
 *     }
 *     leaf resvd1 {
 *         type uint8;
 *     }
 *     leaf rsvd {
 *         type uint8;
 *     }
 *     leaf D {
 *         type boolean;
 *     }
 *     leaf C {
 *         type boolean;
 *     }
 *     leaf R {
 *         type boolean;
 *     }
 *     leaf info-sub-elements {
 *         type binary;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/ac-descriptor&lt;/i&gt;
 *
 */
public interface AcDescriptor
    extends
    DataObject,
    MsgElementHdr,
    AcDescriptorDtlsPolicy
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","ac-descriptor"));

    java.lang.Integer getStations();
    
    java.lang.Integer getLimit();
    
    java.lang.Integer getActiveWtp();
    
    java.lang.Integer getMaxWtp();
    
    java.lang.Short getSecurity();
    
    java.lang.Short getRMacField();
    
    java.lang.Short getResvd1();
    
    byte[] getInfoSubElements();

}

