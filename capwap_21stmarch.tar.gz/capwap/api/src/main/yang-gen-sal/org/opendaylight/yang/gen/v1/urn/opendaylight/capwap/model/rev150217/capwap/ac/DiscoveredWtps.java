package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.CapwapAc;
import org.opendaylight.yangtools.yang.binding.ChildOf;
import org.opendaylight.yangtools.yang.binding.Identifiable;
import org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.DiscoveredWtp;
import org.opendaylight.yangtools.yang.binding.Augmentable;


/**
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * list discovered-wtps {
 *     key "ipv4-addr"
 *     leaf ipv4-addr {
 *         type string;
 *     }
 *     container board-data {
 *         leaf vendorid {
 *             type vendor-id;
 *         }
 *         leaf type {
 *             type uint16;
 *         }
 *         leaf length {
 *             type uint16;
 *         }
 *         leaf value {
 *             type binary;
 *         }
 *         uses wtp-board-data;
 *     }
 *     container descriptor {
 *         leaf max-radios {
 *             type uint8;
 *         }
 *         leaf radios-in-use {
 *             type uint8;
 *         }
 *         leaf num-encrypt {
 *             type uint8;
 *         }
 *         leaf vendorid {
 *             type vendor-id;
 *         }
 *         leaf type {
 *             type uint16;
 *         }
 *         leaf length {
 *             type uint16;
 *         }
 *         leaf value {
 *             type binary;
 *         }
 *         leaf resvd {
 *             type uint8;
 *         }
 *         leaf wbid {
 *             type uint8;
 *         }
 *         leaf capabilities {
 *             type uint16;
 *         }
 *         uses wtp-descriptor;
 *     }
 *     container frame-tunnel-mode {
 *         leaf rsvd {
 *             type uint8;
 *         }
 *         leaf bit-n {
 *             type boolean;
 *         }
 *         leaf bit-e {
 *             type boolean;
 *         }
 *         leaf bit-l {
 *             type boolean;
 *         }
 *         leaf bit-r {
 *             type boolean;
 *         }
 *         uses wtp-frame-tunnel-mode;
 *     }
 *     container mac-type {
 *         leaf mac-type {
 *             type uint8;
 *         }
 *         uses wtp-mac-type;
 *     }
 *     container radio-info {
 *         leaf radio-id {
 *             type uint8;
 *         }
 *         leaf rsvd {
 *             type uint8;
 *         }
 *         leaf rsvd1 {
 *             type uint16;
 *         }
 *         leaf rsvd2 {
 *             type uint8;
 *         }
 *         leaf rsvd3 {
 *             type uint8;
 *         }
 *         leaf type-n {
 *             type boolean;
 *         }
 *         leaf type-g {
 *             type boolean;
 *         }
 *         leaf type-a {
 *             type boolean;
 *         }
 *         leaf type-b {
 *             type boolean;
 *         }
 *         uses wtp-radio-info;
 *     }
 *     container discovery-type {
 *         leaf discovery-type {
 *             type uint8;
 *         }
 *         uses wtp-discovery-type;
 *     }
 *     uses discovered-wtp;
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/capwap-ac/discovered-wtps&lt;/i&gt;
 *
 * &lt;p&gt;To create instances of this class use {@link org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtpsBuilder}.
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtpsBuilder
 * @see org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtpsKey
 *
 */
public interface DiscoveredWtps
    extends
    ChildOf<CapwapAc>,
    Augmentable<org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217.capwap.ac.DiscoveredWtps>,
    DiscoveredWtp,
    Identifiable<DiscoveredWtpsKey>
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","discovered-wtps"));

    java.lang.String getIpv4Addr();
    
    /**
     * Returns Primary Key of Yang List Type
     *
     */
    DiscoveredWtpsKey getKey();

}

