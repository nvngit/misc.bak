package org.opendaylight.yang.gen.v1.urn.opendaylight.capwap.model.rev150217;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.binding.DataObject;


/**
 * Capwap Preamble
 *
 * &lt;p&gt;This class represents the following YANG schema fragment defined in module &lt;b&gt;capwap&lt;/b&gt;
 * &lt;br&gt;(Source path: &lt;i&gt;META-INF/yang/capwap.yang&lt;/i&gt;):
 * &lt;pre&gt;
 * grouping capwap-preamble {
 *     leaf version {
 *         type capwap-version;
 *     }
 *     leaf type {
 *         type capwap-pkt-type;
 *     }
 * }
 * &lt;/pre&gt;
 * The schema path to identify an instance is
 * &lt;i&gt;capwap/capwap-preamble&lt;/i&gt;
 *
 */
public interface CapwapPreamble
    extends
    DataObject
{



    public static final QName QNAME = org.opendaylight.yangtools.yang.common.QName.cachedReference(org.opendaylight.yangtools.yang.common.QName.create("urn:opendaylight:capwap:model","2015-02-17","capwap-preamble"));

    CapwapVersion getVersion();
    
    CapwapPktType getType();

}

