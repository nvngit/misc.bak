package org.opendaylight.capwap;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class ODLCapwapACServer implements ODLCapwapACBaseServer {

    private final DatagramSocket socket;
    private final int port;

    public ODLCapwapACServer() throws SocketException {
        this.port = 5246;
        this.socket = new DatagramSocket(port);
    }

    @Override
    public void start() throws Exception {
        while (true) {
            byte buffer[] = new byte[256];
            DatagramPacket data = new DatagramPacket(buffer, buffer.length);
            socket.receive(data);
            System.out.print("Data recieved : " + new String(data.getData()));
            System.out.println(" From : " + data.getAddress() + ":" + data.getPort());
            //socket.send(data);
        }
    }

    @Override
    public void close() throws Exception {
        socket.close();
    }
}

