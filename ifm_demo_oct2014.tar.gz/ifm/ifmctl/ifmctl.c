#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <poll.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>
#include <linux/genetlink.h>
#include "../include/ifm.h"

/*
 * Generic macros for dealing with netlink sockets. Might be duplicated
 * elsewhere. It is recommended that commercial grade applications use
 * libnl or libnetlink and use the interfaces provided by the library
 */
#define GENLMSG_DATA(glh) ((void *)(NLMSG_DATA(glh) + GENL_HDRLEN))
#define GENLMSG_PAYLOAD(glh) (NLMSG_PAYLOAD(glh, 0) - GENL_HDRLEN)
#define NLA_DATA(na) ((void *)((char*)(na) + NLA_HDRLEN))
//#define NLA_PAYLOAD(len) (len - NLA_HDRLEN)


#define IFM_GENL_FAMILY		"IFM"

int done = 0;
int nl_sd; /*the socket*/

/*
 * Create a raw netlink socket and bind
 */
static int create_nl_socket(int protocol, int groups)
{
        socklen_t addr_len;
        int fd;
        struct sockaddr_nl local;
        
        fd = socket(AF_NETLINK, SOCK_RAW, protocol);
        if (fd < 0){
		perror("socket");
                return -1;
        }

        memset(&local, 0, sizeof(local));
        local.nl_family = AF_NETLINK;
        local.nl_groups = groups;
        if (bind(fd, (struct sockaddr *) &local, sizeof(local)) < 0)
                goto error;
        
        return fd;
 error:
        close(fd);
        return -1;
}

/*
 * Send netlink message to kernel
 */
int sendto_fd(int s, const char *buf, int bufLen)
{
        struct sockaddr_nl nladdr;
        int r;
        
        memset(&nladdr, 0, sizeof(nladdr));
        nladdr.nl_family = AF_NETLINK;
        
        while ((r = sendto(s, buf, bufLen, 0, (struct sockaddr *) &nladdr,
                           sizeof(nladdr))) < bufLen) {
                if (r > 0) {
                        buf += r;
                        bufLen -= r;
                } else if (errno != EAGAIN)
                        return -1;
        }
        return 0;
}


/*
 * Probe the controller in genetlink to find the family id
 * for the CONTROL_EXMPL family
 */
int get_family_id(int sd)
{
        struct {
                struct nlmsghdr n;
                struct genlmsghdr g;
                char buf[256];
        } family_req;
        
        struct {
                struct nlmsghdr n;
                struct genlmsghdr g;
                char buf[256];
        } ans;

        int id;
        struct nlattr *na;
        int rep_len;

        /* Get family name */
        family_req.n.nlmsg_type = GENL_ID_CTRL;
        family_req.n.nlmsg_flags = NLM_F_REQUEST;
        family_req.n.nlmsg_seq = 0;
        family_req.n.nlmsg_pid = getpid();
        family_req.n.nlmsg_len = NLMSG_LENGTH(GENL_HDRLEN);
        family_req.g.cmd = CTRL_CMD_GETFAMILY;
        family_req.g.version = 0x1;

        na = (struct nlattr *) GENLMSG_DATA(&family_req);
        na->nla_type = CTRL_ATTR_FAMILY_NAME;
        /*------change here--------*/
        na->nla_len = strlen(IFM_GENL_FAMILY) + 1 + NLA_HDRLEN;
        strcpy(NLA_DATA(na), IFM_GENL_FAMILY);
        
        family_req.n.nlmsg_len += NLMSG_ALIGN(na->nla_len);

        if (sendto_fd(sd, (char *) &family_req, family_req.n.nlmsg_len) < 0)
		return -1;
    
	rep_len = recv(sd, &ans, sizeof(ans), 0);
        if (rep_len < 0){
		return -1;
	}

        /* Validate response message */
        if (!NLMSG_OK((&ans.n), rep_len)){
		return -1;
	}

        if (ans.n.nlmsg_type == NLMSG_ERROR) { /* error */
                return -1;
        }

        na = (struct nlattr *) GENLMSG_DATA(&ans);
        na = (struct nlattr *) ((char *) na + NLA_ALIGN(na->nla_len));
        if (na->nla_type == CTRL_ATTR_FAMILY_ID) {
                id = *(__u16 *) NLA_DATA(na);
        }
        return id;
}

/*
 * Usage:
 * ./ifm-ctl <cmd_code> <type> <id1> <id2>
 * 	cmd_code:
 *		1 - Create
 *		2 - Delete
 *	type:
 *		1 - VLAN
 *		2 - Port-Channel
 *
 *	id1:
 *		VlanID (Start)
 *	id2:
 *		VlanID (End)
 */
static void
ifmctl_usage (void)
{
	printf ("Usage: ./ifm-ctl <cmd> <type> <id1> [id2]\n");
	printf ("\t\t\tcmd: 1 - Create, 2 - Delete\n");
	printf ("\t\t\ttype: 1 - VLAN, 2 - Port-Channel\n");
	printf ("\t\t\tid1: - ID Start\n");
	printf ("\t\t\tid2: - ID End (Optional)\n");
}

int parse_cmd_input(int argc, char **argv, struct ifm_cfg_msg *cfg)
{
	if ((argc != 4) && (argc != 5)) {
		ifmctl_usage ();
		return 1;
	}

	cfg->cmd = atoi (argv[1]);
	cfg->type = atoi (argv[2]);
	cfg->arg1 = atoi (argv[3]);
	cfg->arg2 = 0;
	if (argc == 5) {
		cfg->arg2 = atoi (argv[4]);
		if (cfg->arg2 < cfg->arg1) {
			printf ("Error: id2 has to be bigger than id1\n");
			ifmctl_usage ();
			return 1;
		}
	}

	if ((cfg->type == 1) && ((cfg->arg1 > IFM_MAX_VLAN_DEV) || (cfg->arg2 > IFM_MAX_VLAN_DEV))) {
		printf ("Invalid id value. Max value is %d\n", IFM_MAX_VLAN_DEV);
		return 1;
	}
	if ((cfg->type == 2) && ((cfg->arg1 > IFM_MAX_PO_DEV) || (cfg->arg2 > IFM_MAX_PO_DEV))) {
		printf ("Invalid id value. Max value is %d\n", IFM_MAX_PO_DEV);
		return 1;
	}
	return 0;
}

int main(int argc, char **argv)
{
	int rep_len; 
	struct sockaddr_nl nladdr;
        int r;
	struct ifm_cfg_msg cfg;
	struct ifm_cfg_msg *resp_cfg;
        int id;
	struct {
                struct nlmsghdr n;
                struct genlmsghdr g;
                char buf[256];
        } ans;

        struct {
                struct nlmsghdr n;
                struct genlmsghdr g;
                char buf[256];
        } req;
        struct nlattr *na;
	int rc;

	rc = parse_cmd_input (argc, argv, &cfg);
	if (rc != 0) {
		return 0;
	}

        nl_sd = create_nl_socket(NETLINK_GENERIC,0);
        if(nl_sd < 0){
                printf("create failure\n");
                return 0;
        }

        id = get_family_id(nl_sd);
	if (id <= 0) {
		printf ("Error. No IFM Generic Netlink Family found\n");
		return 0;
	}

        /* Send command needed */
        req.n.nlmsg_len = NLMSG_LENGTH(GENL_HDRLEN);
        req.n.nlmsg_type = id;
        req.n.nlmsg_flags = NLM_F_REQUEST;
        req.n.nlmsg_seq = 60;
        req.n.nlmsg_pid = getpid();
        req.g.cmd = IFM_CMD_CFG;

        /*compose message*/
        na = (struct nlattr *) GENLMSG_DATA(&req);
        na->nla_type = IFM_ATTRIB_CFG_MSG; //DOC_EXMPL_A_MSG
	int mlength = sizeof (struct ifm_cfg_msg);
        na->nla_len = mlength+NLA_HDRLEN; //message length
        memcpy(NLA_DATA(na), &cfg, mlength);
        req.n.nlmsg_len += NLMSG_ALIGN(na->nla_len);

        /*send message*/

        memset(&nladdr, 0, sizeof(nladdr));
        nladdr.nl_family = AF_NETLINK;

	r = sendto(nl_sd, (char *)&req, req.n.nlmsg_len, 0,  
			  (struct sockaddr *) &nladdr, sizeof(nladdr));

	rep_len = recv(nl_sd, &ans, sizeof(ans), 0);
        /* Validate response message */
        if (ans.n.nlmsg_type == NLMSG_ERROR) { /* error */
                printf("error received NACK - leaving \n");
               	return -1;
        }
        if (rep_len < 0) {
               	printf("error receiving reply message via Netlink \n");
               	return -1;
        }
        if (!NLMSG_OK((&ans.n), rep_len)) {
               	printf("invalid reply message received via Netlink\n");
		return -1;
	}

        rep_len = GENLMSG_PAYLOAD(&ans.n);
        /*parse reply message*/
        na = (struct nlattr *) GENLMSG_DATA(&ans);
        resp_cfg = (struct ifm_cfg_msg *)NLA_DATA(na);
	if (resp_cfg->rc != 0) {
        	printf("Operation failed. return code: %#x\n", resp_cfg->rc);
	}
	else
        	printf("Operation successful.\n");

        close(nl_sd);
       
}






