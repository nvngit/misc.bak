#include <linux/module.h>      // for all modules 
#include <linux/init.h>        // for entry/exit macros 
#include <linux/kernel.h>      // for printk priority macros 
#include <asm/current.h>       // process information, just for fun 
#include <linux/sched.h>       // for "struct task_struct" 
#include<linux/moduleparam.h>  //for module_param
#include<linux/netdevice.h>  //for module_param
#include <linux/etherdevice.h>
#include <linux/ethtool.h>
#include <net/sock.h>
#include <net/checksum.h>
#include <linux/if_ether.h>	/* For the statistics structure. */
#include <linux/if_arp.h>	/* For ARPHRD_ETHER */
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/percpu.h>
#include <net/net_namespace.h>
#include <linux/u64_stats_sync.h>
#include <linux/if_ether.h>
#include <linux/spinlock.h>
#include <linux/if_vlan.h>
#include <linux/genetlink.h>
#include <net/genetlink.h>
#include "../include/ifm.h"


static struct net_device *g_vlan_dev_list[IFM_MAX_VLAN_DEV];
static struct net_device *g_po_dev_list[IFM_MAX_PO_DEV];
unsigned char g_base_macaddr[6] = {0x00, 0x01, 0x2, 0x3, 0x0, 0x0};
unsigned char g_base2_macaddr[6] = {0x00, 0x04, 0x5, 0x6, 0x0, 0x0};

static int ifm_dev_init(struct net_device *dev);
static int ifm_open(struct net_device *dev);
static int ifm_close(struct net_device *dev);
static int ifm_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd);

static struct ifm_priv
{
	int id;
	struct net_device *dev;
};

static int 
ifm_dev_init(struct net_device *dev)
{
	int vlanid;
	int poid;

	if (!strncmp (dev->name, "Vlan", 4)) {
		memcpy(dev->dev_addr, g_base_macaddr, ETH_ALEN);
		sscanf (dev->name, "Vlan%d", &vlanid);
		dev->dev_addr[4] = (vlanid & 0xFF00) >> 8;
		dev->dev_addr[5] = (vlanid & 0xFF);
		dev->needed_headroom = 18;
	}
	else {
		memcpy(dev->dev_addr, g_base2_macaddr, ETH_ALEN);
		sscanf (dev->name, "Po%d", &poid);
		dev->dev_addr[4] = (poid & 0xFF00) >> 8;
		dev->dev_addr[5] = (poid & 0xFF);
		dev->needed_headroom = 18;
	}

	return 0;
}

static int 
ifm_open(struct net_device *dev)
{
	dev->flags |= IFF_UP;
	dev->operstate = IF_OPER_UP;
	netif_carrier_on(dev);
	netif_start_queue (dev);
	return 0;
}

static int 
ifm_close(struct net_device *dev)
{
	netif_stop_queue (dev);
	return 0;
}

static int 
ifm_ioctl(struct net_device *dev, struct ifreq *ifr, int cmd)
{
	printk(KERN_ERR "%s:%s, cmd:%d\n", __FUNCTION__, dev->name, cmd);
	return 0;
}

static void 
ifm_dump_skb (struct sk_buff *skb, char *addstr)
{
	int ii;
	unsigned char *dptr;

	printk(KERN_ERR "%s\n", addstr);
	printk(KERN_ERR "len:%d, data_len:%d\n", skb->len, skb->data_len);
	printk(KERN_ERR "mac_len:%d, hdr_len:%d\n", skb->mac_len, skb->hdr_len);
	printk(KERN_ERR "protocol:%d, skb_iif:%d\n", skb->protocol, skb->skb_iif);
	printk(KERN_ERR "vlan_proto:%#x, vlan_tci:%#x\n", skb->vlan_proto, skb->vlan_tci);
	printk(KERN_ERR "inner_protocol:%d, inner_transport_header:%d\n", skb->inner_protocol, skb->inner_transport_header);
	printk(KERN_ERR "inner_network_header:%d, inner_mac_header:%d\n", skb->inner_network_header, skb->inner_mac_header);
	printk(KERN_ERR "transport_header:%d, network_header:%d\n", skb->transport_header, skb->network_header);
	printk(KERN_ERR "mac_header:%d\n", skb->mac_header);
	printk(KERN_ERR "mark:%d\n", skb->mark);
	printk(KERN_ERR "pkt_type:%d\n", skb->pkt_type);
	printk(KERN_ERR "head:%#x\n", skb->head);
	printk(KERN_ERR "data:%#x\n", skb->data);
	printk(KERN_ERR "truesize:%d\n", skb->truesize);
#if 1
	printk(KERN_ERR "full data dump using hdr ptr+64:\n");
	dptr = skb->head;
	for (ii = 0; ii < 128; ii++) {
		printk(KERN_ERR "data[%d]: %.2x\n", ii, dptr[ii]);
	}
#endif

#if 0
	printk(KERN_ERR "data dump using mac_hdr ptr:\n");
	dptr = skb->head + skb->mac_header;
	for (ii = 0; ii < 20; ii++) {
		printk(KERN_ERR "data[%d]: %.2x\n", ii, dptr[ii]);
	}

	printk(KERN_ERR "data dump using network_header ptr:\n");
	dptr = skb->head + skb->network_header;
	for (ii = 0; ii < 20; ii++) {
		printk(KERN_ERR "data[%d]: %.2x\n", ii, dptr[ii]);
	}
#endif

#if 0
	printk(KERN_ERR "data dump using transport ptr:\n");
	dptr = skb->head + skb->transport_header;
	for (ii = 0; ii < 20; ii++) {
		printk(KERN_ERR "data[%d]: %.2x\n", ii, dptr[ii]);
	}
#endif

	return;
}

static netdev_tx_t 
ifm_xmit(struct sk_buff *skb, struct net_device *dev)
{
	if (!strncmp (dev->name, "Vlan", 4)) {
		struct net_device *tx_dev;
		unsigned int vlanid;
		struct vlan_ethhdr *ethhdr;

		sscanf (dev->name, "Vlan%d", &vlanid);

		/*
		 * Insert tag
		 */
		ethhdr = (struct vlan_ethhdr *)skb_push (skb, VLAN_HLEN);

		memmove(skb->data, skb->data + VLAN_HLEN, 2 * ETH_ALEN);
		ethhdr->h_vlan_proto = htons (ETH_P_8021Q);
		ethhdr->h_vlan_TCI = htons (vlanid);
		skb->mac_header -= VLAN_HLEN;

		tx_dev = dev_get_by_name(&init_net, "eth1");
		if (tx_dev) {
			skb->dev = tx_dev;
			dev_queue_xmit (skb);
			dev_put(tx_dev);
		}
	}

	return NETDEV_TX_OK;
}

static int 
ifm_add_slave(struct net_device *dev, struct net_device *slave_dev)
{
	printk(KERN_ERR "%s:%s, slave:%s\n", __FUNCTION__, dev->name, slave_dev->name);

	return 0;
}

static int 
ifm_del_slave(struct net_device *dev, struct net_device *slave_dev)
{
	printk(KERN_ERR "%s:%s, slave:%s\n", __FUNCTION__, dev->name, slave_dev->name);
	return 0;
}

static int 
ifm_setlink(struct net_device *dev, struct nlmsghdr *nlh)
{
	printk(KERN_ERR "%s:%s\n", __FUNCTION__, dev->name);
	return 0;
}

static int 
ifm_dellink(struct net_device *dev, struct nlmsghdr *nlh)
{
	printk(KERN_ERR "%s:%s\n", __FUNCTION__, dev->name);
	return 0;
}

static struct net_device_ops ifm_ops =
{
	.ndo_init 		= ifm_dev_init,
	.ndo_open 		= ifm_open,
	.ndo_stop 		= ifm_close,
	.ndo_start_xmit  	= ifm_xmit,
	.ndo_add_slave		= ifm_add_slave,
	.ndo_del_slave		= ifm_del_slave,
	.ndo_bridge_setlink	= ifm_setlink,
	.ndo_bridge_dellink	= ifm_dellink,
	.ndo_do_ioctl 		= ifm_ioctl
};

static struct net_device *
ifm_init(char *name)
{
	struct net_device *dev;
	dev = alloc_netdev(sizeof(struct ifm_priv), name, ether_setup);
	if (dev == NULL)
	  return NULL;

	dev->netdev_ops = &ifm_ops;
	register_netdev(dev);
	return dev;
}

static void 
ifm_deinit(struct net_device *dev)
{
	unregister_netdev(dev);
	free_netdev(dev);
}

static rx_handler_result_t process_rx (struct sk_buff **pskb)
{
	struct sk_buff *skb = *pskb;
	struct net_device *rx_dev;
	char ifname[64];
	unsigned short vlanid;

	if (skb->vlan_proto == 0) {
		kfree_skb (skb);
		return RX_HANDLER_CONSUMED;
	}

	vlanid = skb->vlan_tci & 0xFFF;

	sprintf (ifname, "Vlan%d", vlanid);
	rx_dev = dev_get_by_name(&init_net, ifname);
	if (rx_dev) {

		skb->dev = rx_dev;
		skb->skb_iif = rx_dev->ifindex;
		//skb->pkt_type = PACKET_BROADCAST;
		skb->pkt_type = PACKET_HOST;
		skb->vlan_tci = 0;
		skb->vlan_proto = 0;

		//ifm_dump_skb (skb, "Before submitting");

		netif_rx (skb);
		dev_put(rx_dev);
	}
	return RX_HANDLER_CONSUMED;
}

/* attribute policy */
static struct nla_policy ifm_genl_policy[IFM_ATTRIB_MAX + 1] = {
	[IFM_ATTRIB_CFG_MSG] = { .type = NLA_BINARY, .len = sizeof(struct ifm_cfg_msg) },
	[IFM_ATTRIB_GET_MSG] = { .type = NLA_BINARY, .len = sizeof(struct ifm_get_msg) },
};

static struct genl_family ifm_gnl_family;

static int
dump_cfg_data (struct ifm_cfg_msg *cfg)
{
	printk (KERN_ERR "cfg.cmd: 	%d\n", cfg->cmd);
	printk (KERN_ERR "cfg.type: 	%d\n", cfg->type);
	printk (KERN_ERR "cfg.arg1: 	%d\n", cfg->arg1);
	printk (KERN_ERR "cfg.arg2: 	%d\n", cfg->arg2);
	printk (KERN_ERR "cfg.rc: 	%d\n", cfg->rc);
	return 0;
}

static int
process_cfg_data (struct ifm_cfg_msg *cfg)
{
	char name[64];
	int end;
	int ii;

	switch (cfg->cmd) {
	case 1:
		end = cfg->arg2;
		if (!end) {
			end = cfg->arg1;
		}

		for (ii = cfg->arg1; ii <= end; ii++) {
			if (cfg->type == 1) {
				if (g_vlan_dev_list[ii]) continue;
				sprintf (name, "Vlan%d", ii);
				g_vlan_dev_list[ii] = ifm_init (name);
			}
			else if (cfg->type == 2) {
				if (g_po_dev_list[ii]) continue;
				sprintf (name, "Po%d", ii);
				g_po_dev_list[ii] = ifm_init (name);
			}
		}
		break;

	case 2:
		end = cfg->arg2;
		if (!end) {
			end = cfg->arg1;
		}

		for (ii = cfg->arg1; ii <= end; ii++) {
			if (cfg->type == 1) {
				if (!g_vlan_dev_list[ii]) continue;
				sprintf (name, "Vlan%d", ii);
				ifm_deinit (g_vlan_dev_list[ii]);
				g_vlan_dev_list[ii] = NULL;
			}
			else if (cfg->type == 2) {
				if (!g_po_dev_list[ii]) continue;
				sprintf (name, "Po%d", ii);
				ifm_deinit (g_po_dev_list[ii]);
				g_po_dev_list[ii] = NULL;
			}
		}
		break;

	default:
		break;
	}

	return 0;
}

int ifm_cfg (struct sk_buff *skb_2, struct genl_info *info)
{
	struct nlattr *na;
	struct sk_buff *skb;
	int rc = 0;
	void *msg_head;
	struct ifm_cfg_msg *cfg = NULL;
	struct ifm_cfg_msg resp_cfg = {0};

	if (info == NULL)
		goto out;

	/*for each attribute there is an index in info->attrs which points to a nlattr structure
	 *in this structure the data is given
	 */
	na = info->attrs[IFM_ATTRIB_CFG_MSG];
	if (na) {
		cfg = (struct ifm_cfg_msg *)nla_data(na);
		if (cfg == NULL) {
			rc = 1;
			goto out;
		}
		else
			rc = process_cfg_data (cfg);
	}

	/* send a message back*/
	/* allocate some memory, since the size is not yet known use NLMSG_GOODSIZE*/	
	skb = genlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (skb == NULL) {
		rc = 2;
		goto out;
	}

	/* create the message headers */
	/* arguments of genlmsg_put: 
	   struct sk_buff *, 
	   int (sending) pid, 
	   int sequence number, 
	   struct genl_family *, 
	   int flags, 
	   u8 command index (why do we need this?)
	*/
	msg_head = genlmsg_put(skb, 0, info->snd_seq+1, &ifm_gnl_family, 0, IFM_CMD_CFG);
	if (msg_head == NULL) {
		rc = -ENOMEM;
		goto out;
	}

	memcpy (&resp_cfg, cfg, sizeof(struct ifm_cfg_msg));
	resp_cfg.rc = rc;

	rc = nla_put (skb, IFM_ATTRIB_CFG_MSG, sizeof(struct ifm_cfg_msg), &resp_cfg);
	if (rc != 0) {
		rc = 3;
		goto out;
	}

	/* finalize the message */
	genlmsg_end(skb, msg_head);

	/* send the message back */
	rc = genlmsg_unicast(&init_net, skb, info->snd_portid);
	if (rc != 0) {
		rc = 4;
		goto out;
	}

	return 0;

out:
	printk(KERN_ERR "an error occured in ifm_cfg: rc=%d\n", rc);
	return 0;
}

/* operation definition */
static struct genl_ops ifm_gnl_ops[] = {
	{.cmd = IFM_CMD_CFG,
	.flags = 0,
	.policy = ifm_genl_policy,
	.doit = ifm_cfg},
};

/* family definition */
static struct genl_family ifm_gnl_family = {
	.id = GENL_ID_GENERATE,
	.hdrsize = 0,
	.name = IFM_FAMILY_NAME,
	.version = 1,
	.maxattr = IFM_ATTRIB_MAX,
	.ops = ifm_gnl_ops,
	.n_ops = ARRAY_SIZE(ifm_gnl_ops),
};

static int base_mac = 0x0;
module_param(base_mac, int, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);

static int __init ifm_module_init (void)
{
	struct net_device *rx_dev;
	int rc;

	rtnl_lock();
	rx_dev = dev_get_by_name(&init_net, "eth1");
	netdev_rx_handler_register (rx_dev, process_rx, NULL);
	rtnl_unlock();

	rc = genl_register_family(&ifm_gnl_family);
	if (rc != 0) {
		goto failure;
	}

	get_random_bytes (&base_mac, 2);
	base_mac = htonl (base_mac) >> 8;
	memcpy (g_base_macaddr, &base_mac, ETH_ALEN);
	g_base_macaddr[3] = 0x1;
	memcpy (g_base2_macaddr, &base_mac, ETH_ALEN);
	g_base2_macaddr[3] = 0x2;
	return 0;

failure:
	return 0;

}

static void __exit ifm_module_exit (void) 
{
	struct net_device *rx_dev;
	int ii;

	rx_dev = dev_get_by_name(&init_net, "eth1");
	rtnl_lock();
	netdev_rx_handler_unregister (rx_dev);
	rtnl_unlock();

	for (ii = 0; ii < IFM_MAX_VLAN_DEV; ii++) {
		ifm_deinit (g_vlan_dev_list[ii]);
	}
	for (ii = 0; ii < IFM_MAX_PO_DEV; ii++) {
		ifm_deinit (g_po_dev_list[ii]);
	}

	genl_unregister_family (&ifm_gnl_family);
}

module_init(ifm_module_init);
module_exit(ifm_module_exit);

MODULE_AUTHOR("Brocade"); 
MODULE_LICENSE("GPL"); 
