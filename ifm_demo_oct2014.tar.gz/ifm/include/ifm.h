#ifndef IFM_H
#define IFM_H

#define IFM_FAMILY_NAME "IFM"

#define IFM_MAX_VLAN_DEV 4095
#define IFM_MAX_PO_DEV 1024

/* commands */
enum {
        IFM_CMD_UNSPEC,
        IFM_CMD_CFG,
        IFM_CMD_GET,
        __IFM_CMD_MAX,
};

#define IFM_CMD_MAX (__IFM_CMD_MAX - 1)

/* attributes */
enum {
        IFM_ATTRIB_UNSPEC,
        IFM_ATTRIB_CFG_MSG,
        IFM_ATTRIB_GET_MSG,
        __IFM_ATTRIB_MAX,
};

#define IFM_ATTRIB_MAX (__IFM_ATTRIB_MAX - 1)

struct ifm_cfg_msg {
	/* 1 - Create Single, 2 - Delete Single, 3 - Create Multiple, 4 - Delete Multiple */
        int cmd;

	/* 1 - VLAN, 2 - Port Channel */
	int type;

        int arg1;
        int arg2;
	int rc;
};

struct ifm_get_msg {
        int cmd;
        int arg1;
        int arg2;
};

#endif
