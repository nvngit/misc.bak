#!/bin/bash

# This script will start VTN coordinator
sudo /usr/share/java/apache-tomcat-7.0.39/bin/catalina.sh stop
sudo /usr/local/vtn/bin/vtn_stop
