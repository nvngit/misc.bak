"""
Provision 3800 Object Definition
Authors: james.luhrsen@hp.com
Created: 2014-10-02
"""
from H3C import *  # noqa


class H3C_5920(H3C):
    '''
    Comware 5920
    '''

    model = '5920'
