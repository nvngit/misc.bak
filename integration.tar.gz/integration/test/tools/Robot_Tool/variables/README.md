This directory stores all predefined variables.
