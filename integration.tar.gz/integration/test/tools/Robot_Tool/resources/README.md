This directory stores all resources files.
