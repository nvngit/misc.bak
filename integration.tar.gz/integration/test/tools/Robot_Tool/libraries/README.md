This directory stores all keywords.
