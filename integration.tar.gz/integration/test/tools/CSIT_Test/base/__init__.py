"""
CSIT test tools.
Homepage: https://github.com/yeasy/CSIT_Test
Updated: 2013-11-07
"""
__all__ = ['restlib', 'testmodule']
